import discord
from discord.ext import commands
import sqlite3
import uuid
from datetime import datetime, timedelta
from github import Github
from dotenv import load_dotenv
import os

# === Load tokens from .env ===
load_dotenv()
DISCORD_TOKEN = os.getenv("MTM5MzA5OTIwOTIxMjk1NjcwMg.GN-zPI.CY5g9EkhLsFL25TNrSHugjpVjeS96lSKIsSjHA")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

# Repo details
REPO_NAME = "Rexuly/lactaseq012"  # format: username/repo
FILE_PATH = "keys.txt"

# === Bot Setup ===
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# === Database Setup ===
conn = sqlite3.connect("keys.db")
cur = conn.cursor()
cur.execute("""
CREATE TABLE IF NOT EXISTS keys (
    key TEXT PRIMARY KEY,
    type TEXT,
    expiry TEXT,
    redeemed_by TEXT,
    hwid TEXT
)
""")
conn.commit()

# === GitHub Setup ===
g = Github(GITHUB_TOKEN)
repo = g.get_repo(REPO_NAME)

def sync_keys_to_github():
    """Sync keys database to GitHub keys.txt"""
    cur.execute("SELECT key, redeemed_by, hwid, expiry FROM keys")
    rows = cur.fetchall()
    content = ""
    for row in rows:
        k, user, hwid, expiry = row
        user = user or "None"
        hwid = hwid or "None"
        expiry = expiry or "None"
        content += f"{k},{user},{hwid},{expiry}\n"

    try:
        file = repo.get_contents(FILE_PATH)
        repo.update_file(FILE_PATH, "Update keys.txt", content, file.sha)
    except:
        repo.create_file(FILE_PATH, "Create keys.txt", content)

def create_key(key_type):
    """Generate a single key"""
    k = str(uuid.uuid4()).replace("-", "").upper()[:16]
    if key_type == "day":
        expiry = (datetime.utcnow() + timedelta(days=1)).isoformat()
    elif key_type == "lifetime":
        expiry = "lifetime"
    else:
        return None
    cur.execute("INSERT INTO keys VALUES (?, ?, ?, ?, ?)", (k, key_type, expiry, None, None))
    conn.commit()
    return k

def redeem_key(k, user_id, hwid):
    cur.execute("SELECT key, type, expiry, redeemed_by, hwid FROM keys WHERE key=?", (k,))
    row = cur.fetchone()
    if not row:
        return False, "Invalid key."

    key, ktype, expiry, redeemed_by, saved_hwid = row

    if redeemed_by and saved_hwid != hwid:
        return False, "Key already used on another HWID."

    if expiry != "lifetime":
        if datetime.utcnow() > datetime.fromisoformat(expiry):
            return False, "Key expired."

    cur.execute("UPDATE keys SET redeemed_by=?, hwid=? WHERE key=?", (user_id, hwid, k))
    conn.commit()
    sync_keys_to_github()
    return True, f"Key redeemed successfully! Type: {ktype}, Expiry: {expiry}"

# === Commands ===
@bot.command()
async def genkeys(ctx, key_type: str, amount: int):
    if not ctx.author.guild_permissions.administrator:
        await ctx.send("❌ You don't have permission to generate keys.")
        return

    if key_type not in ["day", "lifetime"]:
        await ctx.send("❌ Invalid type. Use `day` or `lifetime`.")
        return

    keys = [create_key(key_type) for _ in range(amount)]
    sync_keys_to_github()
    await ctx.send(f"✅ Generated {amount} {key_type} keys:\n" + "\n".join(keys))

@bot.command()
async def redeem(ctx, key: str, hwid: str):
    success, msg = redeem_key(key, str(ctx.author.id), hwid)
    if success:
        await ctx.send(f"✅ {msg}")
    else:
        await ctx.send(f"❌ {msg}")

@bot.command()
async def mykey(ctx):
    cur.execute("SELECT key, type, expiry, hwid FROM keys WHERE redeemed_by=?", (str(ctx.author.id),))
    row = cur.fetchone()
    if row:
        await ctx.send(f"🔑 Key: {row[0]}\nType: {row[1]}\nExpiry: {row[2]}\nHWID: {row[3]}")
    else:
        await ctx.send("❌ You don't have a redeemed key.")

@bot.command()
async def checkkey(ctx, key: str):
    cur.execute("SELECT key, type, expiry, redeemed_by, hwid FROM keys WHERE key=?", (key,))
    row = cur.fetchone()
    if row:
        await ctx.send(f"🔑 Key Info:\nType: {row[1]}\nExpiry: {row[2]}\nRedeemed by: {row[3]}\nHWID: {row[4]}")
    else:
        await ctx.send("❌ Key not found.")

# === Start Bot ===
bot.run(DISCORD_TOKEN)
