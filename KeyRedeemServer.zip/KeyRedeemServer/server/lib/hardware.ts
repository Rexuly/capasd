import crypto from "crypto";
import os from "os";

export function generateHardwareId(userAgent?: string): string {
  const systemInfo = {
    platform: os.platform(),
    arch: os.arch(),
    hostname: os.hostname(),
    cpus: os.cpus().length,
    totalmem: os.totalmem(),
    userAgent: userAgent || "unknown"
  };

  const infoString = JSON.stringify(systemInfo);
  return crypto.createHash("sha256").update(infoString).digest("hex").substring(0, 16).toUpperCase();
}

export function validateHardwareId(hardwareId: string): boolean {
  return /^[A-F0-9]{16}$/.test(hardwareId);
}
