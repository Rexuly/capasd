import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { botManager } from "./discord/botManager";
import { 
  insertKeySchema, 
  redeemKeySchema, 
  loginSchema, 
  insertAdminSchema,
  insertDiscordBotCodeSchema,
  updateDiscordBotCodeSchema,
  insertAdminInvitationSchema,
  adminInviteAcceptSchema
} from "@shared/schema";
import { generateHardwareId } from "./lib/hardware";
import { randomBytes } from "crypto";
import { authenticateToken, generateToken, type AuthRequest } from "./middleware/auth";
import { initializeDiscordBot, sendDiscordWebhook } from "./discord/bot";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Initialize Discord bot
  initializeDiscordBot().catch(console.error);

  // Authentication endpoints
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const admin = await storage.verifyAdminPassword(username, password);
      
      if (!admin) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = generateToken({
        id: admin.id,
        username: admin.username,
        role: admin.role
      });

      res.json({
        success: true,
        token,
        admin: {
          id: admin.id,
          username: admin.username,
          role: admin.role
        }
      });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid request data" 
      });
    }
  });

  app.post("/api/logout", (req, res) => {
    res.json({ success: true, message: "Logged out successfully" });
  });

  // Redeem key endpoint (now supports Discord integration)
  app.post("/api/redeem", async (req, res) => {
    try {
      const { key, hardwareId, discordUserId, discordUsername } = redeemKeySchema.parse(req.body);
      
      const result = await storage.redeemKey(key, hardwareId, discordUserId, discordUsername);
      
      // Send Discord webhook notification if successful and webhook URL is configured
      if (result.success && process.env.DISCORD_WEBHOOK_URL) {
        const embed = {
          title: '🎉 Key Redeemed Successfully',
          color: 0x00ff00,
          fields: [
            { name: 'Key', value: `\`${key}\``, inline: true },
            { name: 'Hardware ID', value: `\`${hardwareId.substring(0, 8)}...\``, inline: true },
            ...(discordUsername ? [{ name: 'Discord User', value: discordUsername, inline: true }] : []),
            { name: 'Time', value: new Date().toLocaleString(), inline: false }
          ],
          timestamp: new Date().toISOString()
        };

        sendDiscordWebhook(process.env.DISCORD_WEBHOOK_URL, embed).catch(console.error);
      }
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(400).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "Invalid request data" 
      });
    }
  });

  // Get hardware ID for current system
  app.get("/api/hardware-id", (req, res) => {
    const userAgent = req.headers["user-agent"];
    const hardwareId = generateHardwareId(userAgent);
    res.json({ hardwareId });
  });

  // Get user status based on hardware ID
  app.get("/api/user-status", async (req, res) => {
    try {
      const { hardwareId } = req.query;
      
      if (!hardwareId || typeof hardwareId !== 'string') {
        return res.status(400).json({ message: "Hardware ID is required" });
      }

      const keys = await storage.getAllKeys();
      const userKeys = keys.filter(key => key.hardwareId === hardwareId && key.isRedeemed);
      
      if (userKeys.length === 0) {
        return res.json({
          keysRedeemed: 0,
          status: "No Active Keys",
          daysRemaining: null,
          activeKey: null
        });
      }

      // Find the most recent active key (not expired)
      const now = new Date();
      const activeKey = userKeys.find(key => new Date(key.expiresAt) > now);
      
      if (!activeKey) {
        return res.json({
          keysRedeemed: userKeys.length,
          status: "Expired",
          daysRemaining: 0,
          activeKey: null
        });
      }

      // Calculate days remaining
      const expirationDate = new Date(activeKey.expiresAt);
      const daysRemaining = Math.ceil((expirationDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

      res.json({
        keysRedeemed: userKeys.length,
        status: "Active",
        daysRemaining: Math.max(0, daysRemaining),
        activeKey: {
          key: activeKey.key,
          expiresAt: activeKey.expiresAt,
          currentUses: activeKey.currentUses,
          maxUses: activeKey.maxUses,
          discordUsername: activeKey.discordUsername
        }
      });
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch user status" 
      });
    }
  });

  // Protected admin endpoints
  app.get("/api/admin/keys", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const keys = await storage.getAllKeys();
      res.json(keys);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch keys" 
      });
    }
  });

  app.post("/api/admin/keys", authenticateToken, async (req: AuthRequest, res) => {
    try {
      // Transform the date string to Date object before validation
      const requestData = {
        ...req.body,
        expiresAt: new Date(req.body.expiresAt)
      };
      const keyData = insertKeySchema.parse(requestData);
      const newKey = await storage.createKey(keyData);
      
      // Send Discord notification for new key creation
      if (process.env.DISCORD_WEBHOOK_URL) {
        const embed = {
          title: '🔑 New Key Created',
          color: 0x0099ff,
          fields: [
            { name: 'Key', value: `\`${newKey.key}\``, inline: true },
            { name: 'Created By', value: req.admin?.username || 'Unknown', inline: true },
            { name: 'Expires', value: new Date(newKey.expiresAt).toLocaleDateString(), inline: true },
            { name: 'Max Uses', value: newKey.maxUses.toString(), inline: true }
          ],
          timestamp: new Date().toISOString()
        };
        sendDiscordWebhook(process.env.DISCORD_WEBHOOK_URL, embed).catch(console.error);
      }
      
      res.json(newKey);
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid key data" 
      });
    }
  });

  app.delete("/api/admin/keys/:id", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { id } = req.params;
      const key = await storage.getKeyById(id);
      const deleted = await storage.deleteKey(id);
      
      if (deleted) {
        // Send Discord notification for key deletion
        if (process.env.DISCORD_WEBHOOK_URL && key) {
          const embed = {
            title: '🗑️ Key Deleted',
            color: 0xff0000,
            fields: [
              { name: 'Key', value: `\`${key.key}\``, inline: true },
              { name: 'Deleted By', value: req.admin?.username || 'Unknown', inline: true },
              { name: 'Time', value: new Date().toLocaleString(), inline: true }
            ],
            timestamp: new Date().toISOString()
          };
          sendDiscordWebhook(process.env.DISCORD_WEBHOOK_URL, embed).catch(console.error);
        }
        
        res.json({ success: true, message: "Key deleted successfully" });
      } else {
        res.status(404).json({ message: "Key not found" });
      }
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to delete key" 
      });
    }
  });

  app.put("/api/admin/keys/:id", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedKey = await storage.updateKey(id, updates);
      
      if (updatedKey) {
        res.json(updatedKey);
      } else {
        res.status(404).json({ message: "Key not found" });
      }
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to update key" 
      });
    }
  });

  // Generate random key
  app.post("/api/admin/generate-key", authenticateToken, (req, res) => {
    const segments = Array.from({ length: 4 }, () => 
      randomBytes(2).toString('hex').toUpperCase()
    );
    const key = segments.join('-');
    res.json({ key });
  });

  // Get admin stats
  app.get("/api/admin/stats", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const keys = await storage.getAllKeys();
      const discordLogs = await storage.getAllDiscordLogs();
      const now = new Date();
      
      const stats = {
        total: keys.length,
        active: keys.filter(k => k.isRedeemed && new Date(k.expiresAt) > now).length,
        expired: keys.filter(k => new Date(k.expiresAt) <= now).length,
        unused: keys.filter(k => !k.isRedeemed && new Date(k.expiresAt) > now).length,
        discordRedemptions: keys.filter(k => k.discordUserId).length,
        recentActivity: discordLogs.slice(0, 10)
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch stats" 
      });
    }
  });

  // Discord logs endpoint
  app.get("/api/admin/discord-logs", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const logs = await storage.getAllDiscordLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch Discord logs" 
      });
    }
  });

  // Change admin password endpoint
  app.post("/api/admin/change-password", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current and new passwords are required" });
      }
      
      if (newPassword.length < 6) {
        return res.status(400).json({ message: "New password must be at least 6 characters long" });
      }

      const success = await storage.changeAdminPassword(req.admin?.id!, currentPassword, newPassword);
      
      if (success) {
        res.json({ success: true, message: "Password updated successfully" });
      } else {
        res.status(401).json({ message: "Current password is incorrect" });
      }
    } catch (error) {
      console.error("Password change error:", error);
      res.status(500).json({ 
        message: "Failed to change password. Please try again." 
      });
    }
  });

  // Change admin username endpoint
  app.post("/api/admin/change-username", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { currentPassword, newUsername } = req.body;
      
      if (!currentPassword || !newUsername) {
        return res.status(400).json({ message: "Current password and new username are required" });
      }
      
      if (newUsername.length < 3) {
        return res.status(400).json({ message: "Username must be at least 3 characters long" });
      }

      const success = await storage.changeAdminUsername(req.admin?.id!, currentPassword, newUsername);
      
      if (success) {
        res.json({ success: true, message: "Username updated successfully" });
      } else {
        res.status(401).json({ message: "Current password is incorrect or username already exists" });
      }
    } catch (error) {
      console.error("Username change error:", error);
      res.status(500).json({ 
        message: "Failed to change username. Please try again." 
      });
    }
  });

  // Admin management endpoints
  app.post("/api/admin/create-admin", authenticateToken, async (req: AuthRequest, res) => {
    try {
      if (req.admin?.role !== 'super_admin') {
        return res.status(403).json({ message: "Only super admins can create new admins" });
      }

      const adminData = insertAdminSchema.parse(req.body);
      const newAdmin = await storage.createAdmin(adminData);
      
      res.json({
        id: newAdmin.id,
        username: newAdmin.username,
        role: newAdmin.role,
        createdAt: newAdmin.createdAt
      });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid admin data" 
      });
    }
  });

  // Discord Bot Code Management endpoints
  app.get("/api/admin/discord-bot-code", authenticateToken, async (req, res) => {
    try {
      const botCode = await storage.getAllDiscordBotCode();
      res.json(botCode);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch Discord bot code" });
    }
  });

  app.get("/api/admin/discord-bot-code/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const botCode = await storage.getDiscordBotCodeById(id);
      
      if (!botCode) {
        return res.status(404).json({ message: "Discord bot code not found" });
      }
      
      res.json(botCode);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch Discord bot code" });
    }
  });

  app.post("/api/admin/discord-bot-code", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const insertData = insertDiscordBotCodeSchema.parse(req.body);
      const botCode = await storage.createDiscordBotCode(insertData);
      
      res.status(201).json({
        success: true,
        message: "Discord bot code created successfully",
        botCode
      });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid bot code data" 
      });
    }
  });

  app.put("/api/admin/discord-bot-code/:id", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { id } = req.params;
      const updateData = updateDiscordBotCodeSchema.parse(req.body);
      
      const updatedBotCode = await storage.updateDiscordBotCode(id, updateData);
      
      if (!updatedBotCode) {
        return res.status(404).json({ message: "Discord bot code not found" });
      }
      
      res.json({
        success: true,
        message: "Discord bot code updated successfully",
        botCode: updatedBotCode
      });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid update data" 
      });
    }
  });

  app.delete("/api/admin/discord-bot-code/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      
      // Stop bot if it's running
      try {
        await botManager.stopBot(id);
      } catch (botError) {
        console.error('Error stopping bot:', botError);
      }
      
      const deleted = await storage.deleteDiscordBotCode(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Discord bot code not found" });
      }
      
      res.json({
        success: true,
        message: "Discord bot code deleted successfully"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete Discord bot code" });
    }
  });

  app.post("/api/admin/discord-bot-code/:id/deploy", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { id } = req.params;
      const deployedBy = req.admin?.id || "unknown";
      
      // Get the bot code
      const botCode = await storage.getDiscordBotCodeById(id);
      if (!botCode) {
        return res.status(404).json({ success: false, message: "Bot code not found" });
      }

      // Start the bot using bot manager
      try {
        await botManager.startBot(botCode.id, botCode.fileName, botCode.code, botCode.language);
      } catch (botError) {
        console.error('Bot manager error:', botError);
        // Continue with database update even if bot fails to start
      }
      
      const result = await storage.deployDiscordBotCode(id, deployedBy);
      
      if (!result.success) {
        return res.status(400).json({ message: result.message });
      }
      
      res.json({
        success: true,
        message: result.message
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to deploy Discord bot code" });
    }
  });

  // Admin Invitation endpoints
  app.get("/api/admin/invitations", authenticateToken, async (req, res) => {
    try {
      const invitations = await storage.getAllAdminInvitations();
      res.json(invitations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch admin invitations" });
    }
  });

  app.post("/api/admin/invitations", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const insertData = insertAdminInvitationSchema.parse(req.body);
      const createdBy = req.admin?.id || "unknown";
      
      const invitation = await storage.createAdminInvitation(insertData, createdBy);
      
      res.status(201).json({
        success: true,
        message: "Admin invitation created successfully",
        invitation
      });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid invitation data" 
      });
    }
  });

  app.delete("/api/admin/invitations/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteAdminInvitation(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Admin invitation not found" });
      }
      
      res.json({
        success: true,
        message: "Admin invitation deleted successfully"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete admin invitation" });
    }
  });

  // Public admin invitation acceptance endpoint
  app.post("/api/accept-invitation", async (req, res) => {
    try {
      const { inviteCode, username, password } = adminInviteAcceptSchema.parse(req.body);
      
      const invitation = await storage.getAdminInvitationByCode(inviteCode);
      
      if (!invitation) {
        return res.status(404).json({ message: "Invalid invitation code" });
      }
      
      if (invitation.used) {
        return res.status(400).json({ message: "Invitation has already been used" });
      }
      
      if (new Date() > invitation.expiresAt) {
        return res.status(400).json({ message: "Invitation has expired" });
      }
      
      // Check if username already exists
      const existingAdmin = await storage.getAdminByUsername(username);
      if (existingAdmin) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Create new admin
      const newAdmin = await storage.createAdmin({
        username,
        passwordHash: password, // Will be hashed in storage
        role: invitation.role
      });
      
      // Mark invitation as used
      await storage.useAdminInvitation(inviteCode);
      
      res.status(201).json({
        success: true,
        message: "Admin account created successfully",
        admin: {
          id: newAdmin.id,
          username: newAdmin.username,
          role: newAdmin.role
        }
      });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to accept invitation" 
      });
    }
  });

  // Deployment History endpoints
  app.get("/api/admin/deployment-history", authenticateToken, async (req, res) => {
    try {
      const history = await storage.getDeploymentHistory();
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch deployment history" });
    }
  });

  // Bot Management endpoints
  app.get("/api/admin/bot-status/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const status = botManager.getBotStatus(id);
      
      if (!status) {
        return res.status(404).json({ message: "Bot not found" });
      }
      
      res.json(status);
    } catch (error) {
      res.status(500).json({ message: "Failed to get bot status" });
    }
  });

  app.get("/api/admin/bot-logs/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const logs = botManager.getBotLogs(id, limit);
      
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get bot logs" });
    }
  });

  app.post("/api/admin/bot-stop/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      await botManager.stopBot(id);
      res.json({ success: true, message: "Bot stopped successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to stop bot" });
    }
  });

  app.post("/api/admin/bot-restart/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      
      // Get the bot code
      const botCode = await storage.getDiscordBotCodeById(id);
      if (!botCode) {
        return res.status(404).json({ message: "Bot code not found" });
      }

      await botManager.restartBot(botCode.id, botCode.fileName, botCode.code, botCode.language);
      res.json({ success: true, message: "Bot restarted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to restart bot" });
    }
  });

  app.delete("/api/admin/bot-logs/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      botManager.clearBotLogs(id);
      res.json({ success: true, message: "Bot logs cleared successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to clear bot logs" });
    }
  });

  app.get("/api/admin/all-bots-status", authenticateToken, async (req, res) => {
    try {
      const bots = botManager.getAllBots();
      res.json(bots);
    } catch (error) {
      res.status(500).json({ message: "Failed to get all bots status" });
    }
  });

  const httpServer = createServer(app);
  
  // WebSocket setup for real-time bot monitoring
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    // Send current bot statuses
    const bots = botManager.getAllBots();
    ws.send(JSON.stringify({ type: 'initial', data: bots }));
    
    // Bot manager event handlers
    const onLog = (data: any) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'log', data }));
      }
    };
    
    const onStatusChange = (data: any) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'statusChange', data }));
      }
    };
    
    botManager.on('log', onLog);
    botManager.on('statusChange', onStatusChange);
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      botManager.off('log', onLog);
      botManager.off('statusChange', onStatusChange);
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });

  return httpServer;
}
