import { randomUUID } from "crypto";
import * as bcrypt from "bcryptjs";
import {
  type Admin,
  type InsertAdmin,
  type Key,
  type InsertKey,
  type DiscordLog,
  type InsertDiscordLog,
  type DiscordBotCode,
  type InsertDiscordBotCode,
  type UpdateDiscordBotCode,
  type AdminInvitation,
  type InsertAdminInvitation,
  type DeploymentHistory,
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // Admin operations
  getAdmin(id: string): Promise<Admin | undefined>;
  getAdminByUsername(username: string): Promise<Admin | undefined>;
  createAdmin(insertAdmin: InsertAdmin): Promise<Admin>;
  verifyAdminPassword(username: string, password: string): Promise<Admin | null>;

  // Key operations
  getAllKeys(): Promise<Key[]>;
  getKeyByValue(key: string): Promise<Key | undefined>;
  getKeyById(id: string): Promise<Key | undefined>;
  createKey(insertKey: InsertKey): Promise<Key>;
  updateKey(id: string, updates: Partial<Key>): Promise<Key | undefined>;
  deleteKey(id: string): Promise<boolean>;
  renewKey(id: string, daysToAdd: number): Promise<Key | undefined>;

  // Discord log operations
  getAllDiscordLogs(): Promise<DiscordLog[]>;
  createDiscordLog(insertDiscordLog: InsertDiscordLog): Promise<DiscordLog>;

  // Discord bot code operations
  getAllDiscordBotCode(): Promise<DiscordBotCode[]>;
  getDiscordBotCodeById(id: string): Promise<DiscordBotCode | undefined>;
  createDiscordBotCode(code: InsertDiscordBotCode): Promise<DiscordBotCode>;
  updateDiscordBotCode(id: string, updates: UpdateDiscordBotCode): Promise<DiscordBotCode | undefined>;
  deleteDiscordBotCode(id: string): Promise<boolean>;
  deployDiscordBotCode(id: string, deployedBy: string): Promise<{ success: boolean; message: string }>;
  
  // Admin invitations
  getAllAdminInvitations(): Promise<AdminInvitation[]>;
  createAdminInvitation(invitation: InsertAdminInvitation, createdBy: string): Promise<AdminInvitation>;
  getAdminInvitationByCode(inviteCode: string): Promise<AdminInvitation | undefined>;
  useAdminInvitation(inviteCode: string): Promise<AdminInvitation | undefined>;
  deleteAdminInvitation(id: string): Promise<boolean>;
  
  // Deployment history
  getDeploymentHistory(): Promise<DeploymentHistory[]>;
  createDeploymentRecord(fileId: string, version: number, deployedBy: string, status: string, logs?: string): Promise<DeploymentHistory>;
}

export class MemStorage implements IStorage {
  private admins: Map<string, Admin>;
  private keys: Map<string, Key>;
  private discordLogs: Map<string, DiscordLog>;
  private discordBotCode: Map<string, DiscordBotCode>;
  private adminInvitations: Map<string, AdminInvitation>;
  private deploymentHistory: Map<string, DeploymentHistory>;

  constructor() {
    this.admins = new Map();
    this.keys = new Map();
    this.discordLogs = new Map();
    this.discordBotCode = new Map();
    this.adminInvitations = new Map();
    this.deploymentHistory = new Map();
    
    // Create default admin
    this.initializeDefaultAdmin();
    
    // Initialize default Discord bot code with Python support
    this.initializeDefaultDiscordBotCode();
    
    // Add some sample keys for demonstration
    const sampleKeys: Key[] = [
      {
        id: "1",
        key: "ABCD-1234-EFGH-5678",
        isRedeemed: true,
        hardwareId: "7F3A9B2E1C4D8F6A",
        discordUserId: "123456789012345678",
        discordUsername: "testuser#1234",
        createdAt: new Date("2024-01-15"),
        expiresAt: new Date("2024-12-15"),
        redeemedAt: new Date("2024-01-16"),
        maxUses: 1,
        currentUses: 1,
        allowMultipleHardware: false,
        notes: "Test key for development"
      },
      {
        id: "2", 
        key: "WXYZ-9876-MNOP-4321",
        isRedeemed: false,
        hardwareId: null,
        discordUserId: null,
        discordUsername: null,
        createdAt: new Date("2024-01-12"),
        expiresAt: new Date("2024-12-12"),
        redeemedAt: null,
        maxUses: 1,
        currentUses: 0,
        allowMultipleHardware: false,
        notes: "Unused key ready for redemption"
      },
      {
        id: "3",
        key: "QRST-5555-UVWX-8888", 
        isRedeemed: true,
        hardwareId: "9B4C2F7A3E6D1A5C",
        discordUserId: "987654321098765432",
        discordUsername: "expireduser#5678",
        createdAt: new Date("2023-12-01"),
        expiresAt: new Date("2023-12-31"),
        redeemedAt: new Date("2023-12-15"),
        maxUses: 1,
        currentUses: 1,
        allowMultipleHardware: false,
        notes: "Expired test key"
      }
    ];
    
    sampleKeys.forEach(key => this.keys.set(key.id, key));
  }

  private async initializeDefaultAdmin() {
    const hashedPassword = await bcrypt.hash("admin123", 10);
    const defaultAdmin: Admin = {
      id: "admin-1",
      username: "admin",
      passwordHash: hashedPassword,
      role: "admin",
      createdAt: new Date()
    };
    this.admins.set(defaultAdmin.id, defaultAdmin);
  }

  private initializeDefaultDiscordBotCode() {
    // JavaScript Discord bot example
    const jsBot: DiscordBotCode = {
      id: "js-bot-1",
      fileName: "bot.js",
      language: "javascript",
      code: `const { Client, GatewayIntentBits } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('ready', () => {
  console.log('Discord bot is ready!');
});

client.on('messageCreate', (message) => {
  if (message.author.bot) return;
  
  if (message.content === '!ping') {
    message.reply('Pong!');
  }
  
  if (message.content === '!hello') {
    message.reply(\`Hello \${message.author.username}!\`);
  }
});

client.login(process.env.DISCORD_BOT_TOKEN);`,
      description: "Basic Discord bot with ping and hello commands (JavaScript)",
      isActive: true,
      version: 1,
      lastDeployed: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Python Discord bot example
    const pythonBot: DiscordBotCode = {
      id: "python-bot-1", 
      fileName: "bot.py",
      language: "python",
      code: `import discord
from discord.ext import commands
import os
import asyncio

# Set up bot with intents
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')

@bot.command(name='ping')
async def ping(ctx):
    """Responds with Pong!"""
    await ctx.send('Pong!')

@bot.command(name='hello')
async def hello(ctx):
    """Says hello to the user"""
    await ctx.send(f'Hello {ctx.author.mention}!')

@bot.command(name='info')
async def info(ctx):
    """Shows bot information"""
    embed = discord.Embed(
        title="Bot Information",
        description="Discord Key Redemption Bot",
        color=0x00ff00
    )
    embed.add_field(name="Servers", value=len(bot.guilds), inline=True)
    embed.add_field(name="Users", value=len(bot.users), inline=True)
    await ctx.send(embed=embed)

@bot.command(name='redeem')
async def redeem_key(ctx, key: str):
    """Redeem a key command placeholder"""
    # This would connect to your key redemption API
    await ctx.send(f"Key redemption functionality for: {key}")

# Run the bot
if __name__ == "__main__":
    bot.run(os.getenv('DISCORD_BOT_TOKEN'))`,
      description: "Advanced Discord bot with commands and embeds (Python)",
      isActive: false,
      version: 1,
      lastDeployed: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.discordBotCode.set(jsBot.id, jsBot);
    this.discordBotCode.set(pythonBot.id, pythonBot);
  }

  // Admin operations
  async getAdmin(id: string): Promise<Admin | undefined> {
    return this.admins.get(id);
  }

  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    return Array.from(this.admins.values()).find(
      (admin) => admin.username === username,
    );
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertAdmin.passwordHash, 10);
    const admin: Admin = { 
      ...insertAdmin, 
      id, 
      passwordHash: hashedPassword,
      role: insertAdmin.role || "admin",
      createdAt: new Date()
    };
    this.admins.set(id, admin);
    return admin;
  }

  async verifyAdminPassword(username: string, password: string): Promise<Admin | null> {
    const admin = await this.getAdminByUsername(username);
    if (!admin) return null;
    
    const isValid = await bcrypt.compare(password, admin.passwordHash);
    return isValid ? admin : null;
  }

  // Key operations
  async getAllKeys(): Promise<Key[]> {
    return Array.from(this.keys.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getKeyByValue(key: string): Promise<Key | undefined> {
    return Array.from(this.keys.values()).find(k => k.key === key);
  }

  async getKeyById(id: string): Promise<Key | undefined> {
    return this.keys.get(id);
  }

  async createKey(insertKey: InsertKey): Promise<Key> {
    const id = randomUUID();
    const key: Key = {
      ...insertKey,
      id,
      isRedeemed: false,
      hardwareId: null,
      discordUserId: null,
      discordUsername: null,
      createdAt: new Date(),
      redeemedAt: null,
      currentUses: 0,
      maxUses: insertKey.maxUses || 1,
      allowMultipleHardware: insertKey.allowMultipleHardware || false,
      notes: insertKey.notes || null,
    };
    this.keys.set(id, key);
    return key;
  }

  async updateKey(id: string, updates: Partial<Key>): Promise<Key | undefined> {
    const existingKey = this.keys.get(id);
    if (!existingKey) return undefined;
    
    const updatedKey = { ...existingKey, ...updates };
    this.keys.set(id, updatedKey);
    return updatedKey;
  }

  async deleteKey(id: string): Promise<boolean> {
    return this.keys.delete(id);
  }

  async renewKey(id: string, daysToAdd: number): Promise<Key | undefined> {
    const existingKey = this.keys.get(id);
    if (!existingKey) return undefined;

    const newExpiry = new Date(existingKey.expiresAt);
    newExpiry.setDate(newExpiry.getDate() + daysToAdd);

    const updatedKey = { ...existingKey, expiresAt: newExpiry };
    this.keys.set(id, updatedKey);
    return updatedKey;
  }

  // Discord log operations
  async getAllDiscordLogs(): Promise<DiscordLog[]> {
    return Array.from(this.discordLogs.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createDiscordLog(insertDiscordLog: InsertDiscordLog): Promise<DiscordLog> {
    const id = randomUUID();
    const log: DiscordLog = {
      ...insertDiscordLog,
      id,
      keyValue: insertDiscordLog.keyValue || null,
      details: insertDiscordLog.details || null,
      createdAt: new Date(),
    };
    this.discordLogs.set(id, log);
    return log;
  }

  // Discord bot code operations
  async getAllDiscordBotCode(): Promise<DiscordBotCode[]> {
    return Array.from(this.discordBotCode.values()).sort((a, b) => 
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  async getDiscordBotCodeById(id: string): Promise<DiscordBotCode | undefined> {
    return this.discordBotCode.get(id);
  }

  async createDiscordBotCode(insertCode: InsertDiscordBotCode): Promise<DiscordBotCode> {
    const id = randomUUID();
    const code: DiscordBotCode = {
      ...insertCode,
      id,
      language: insertCode.language || 'javascript',
      description: insertCode.description || null,
      isActive: insertCode.isActive || false,
      version: 1,
      lastDeployed: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.discordBotCode.set(id, code);
    return code;
  }

  async updateDiscordBotCode(id: string, updates: UpdateDiscordBotCode): Promise<DiscordBotCode | undefined> {
    const existingCode = this.discordBotCode.get(id);
    if (!existingCode) return undefined;

    const updatedCode: DiscordBotCode = {
      ...existingCode,
      ...updates,
      updatedAt: new Date(),
    };
    this.discordBotCode.set(id, updatedCode);
    return updatedCode;
  }

  async deleteDiscordBotCode(id: string): Promise<boolean> {
    return this.discordBotCode.delete(id);
  }

  async deployDiscordBotCode(id: string, deployedBy: string): Promise<{ success: boolean; message: string }> {
    const code = this.discordBotCode.get(id);
    if (!code) {
      return { success: false, message: "Bot code not found" };
    }

    try {
      const newVersion = code.version + 1;
      const updatedCode: DiscordBotCode = {
        ...code,
        version: newVersion,
        lastDeployed: new Date(),
        updatedAt: new Date(),
      };
      this.discordBotCode.set(id, updatedCode);

      // Create deployment record
      await this.createDeploymentRecord(
        id,
        newVersion,
        deployedBy,
        "success",
        `Successfully deployed ${code.language} bot: ${code.fileName}`
      );

      return { 
        success: true, 
        message: `Successfully deployed ${code.language} bot: ${code.fileName} (v${newVersion})` 
      };
    } catch (error) {
      await this.createDeploymentRecord(
        id,
        code.version,
        deployedBy,
        "failed",
        `Deployment failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
      return { 
        success: false, 
        message: `Deployment failed: ${error instanceof Error ? error.message : 'Unknown error'}` 
      };
    }
  }

  // Admin invitation operations
  async getAllAdminInvitations(): Promise<AdminInvitation[]> {
    return Array.from(this.adminInvitations.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createAdminInvitation(insertInvitation: InsertAdminInvitation, createdBy: string): Promise<AdminInvitation> {
    const id = randomUUID();
    const inviteCode = randomUUID().replace(/-/g, '').substring(0, 16).toUpperCase();
    
    const invitation: AdminInvitation = {
      ...insertInvitation,
      id,
      role: insertInvitation.role || 'admin',
      inviteCode,
      createdBy,
      used: false,
      usedAt: null,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      createdAt: new Date(),
    };
    this.adminInvitations.set(id, invitation);
    return invitation;
  }

  async getAdminInvitationByCode(inviteCode: string): Promise<AdminInvitation | undefined> {
    return Array.from(this.adminInvitations.values()).find(
      invitation => invitation.inviteCode === inviteCode
    );
  }

  async useAdminInvitation(inviteCode: string): Promise<AdminInvitation | undefined> {
    const invitation = await this.getAdminInvitationByCode(inviteCode);
    if (!invitation) return undefined;

    const updatedInvitation: AdminInvitation = {
      ...invitation,
      used: true,
      usedAt: new Date()
    };
    this.adminInvitations.set(invitation.id, updatedInvitation);
    return updatedInvitation;
  }

  async deleteAdminInvitation(id: string): Promise<boolean> {
    return this.adminInvitations.delete(id);
  }

  // Deployment history operations
  async getDeploymentHistory(): Promise<DeploymentHistory[]> {
    return Array.from(this.deploymentHistory.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createDeploymentRecord(
    fileId: string, 
    version: number, 
    deployedBy: string, 
    status: string, 
    logs?: string
  ): Promise<DeploymentHistory> {
    const id = randomUUID();
    const deployment: DeploymentHistory = {
      id,
      fileId,
      version,
      deployedBy,
      status,
      logs: logs || null,
      createdAt: new Date(),
    };
    this.deploymentHistory.set(id, deployment);
    return deployment;
  }
}

export const storage = new MemStorage();