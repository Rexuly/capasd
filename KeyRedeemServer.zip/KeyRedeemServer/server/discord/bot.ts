import { Client, GatewayIntentBits, EmbedBuilder, SlashCommandBuilder, ChannelType } from 'discord.js';
import { storage } from '../storage';
import { generateHardwareId } from '../lib/hardware';

let client: Client | null = null;
let isInitialized = false;

interface DiscordConfig {
  token?: string;
  guildId?: string;
  channelId?: string;
  webhookUrl?: string;
}

export class DiscordBot {
  private client: Client;
  private config: DiscordConfig;

  constructor(config: DiscordConfig) {
    this.config = config;
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
      ],
    });

    this.setupEventHandlers();
  }

  private setupEventHandlers() {
    this.client.once('ready', () => {
      console.log(`🤖 Discord bot logged in as ${this.client.user?.tag}`);
      this.registerCommands();
    });

    this.client.on('interactionCreate', async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      const { commandName } = interaction;

      if (commandName === 'redeem') {
        await this.handleRedeemCommand(interaction);
      } else if (commandName === 'status') {
        await this.handleStatusCommand(interaction);
      }
    });
  }

  private async registerCommands() {
    const commands = [
      new SlashCommandBuilder()
        .setName('redeem')
        .setDescription('Redeem an activation key')
        .addStringOption(option =>
          option.setName('key')
            .setDescription('Your activation key')
            .setRequired(true)
        ),
      
      new SlashCommandBuilder()
        .setName('status')
        .setDescription('Check your key redemption status')
    ];

    try {
      if (this.config.guildId) {
        const guild = await this.client.guilds.fetch(this.config.guildId);
        await guild.commands.set(commands);
        console.log('✅ Discord slash commands registered');
      }
    } catch (error) {
      console.error('❌ Failed to register Discord commands:', error);
    }
  }

  private async handleRedeemCommand(interaction: any) {
    const key = interaction.options.getString('key');
    const discordUserId = interaction.user.id;
    const discordUsername = interaction.user.username;

    // Generate a hardware ID based on Discord user info
    const hardwareId = generateHardwareId(`discord:${discordUserId}`);

    try {
      // Log the redemption attempt
      await storage.createDiscordLog({
        action: 'KEY_REDEEM_ATTEMPT',
        discordUserId,
        discordUsername,
        keyValue: key,
        details: `User attempted to redeem key: ${key}`,
        success: false
      });

      const result = await storage.redeemKey(key, hardwareId, discordUserId, discordUsername);

      const embed = new EmbedBuilder()
        .setColor(result.success ? 0x00ff00 : 0xff0000)
        .setTitle(result.success ? '✅ Key Redeemed Successfully!' : '❌ Redemption Failed')
        .setDescription(result.message)
        .addFields(
          { name: 'Key', value: `\`${key}\``, inline: true },
          { name: 'User', value: `<@${discordUserId}>`, inline: true },
          { name: 'Hardware ID', value: `\`${hardwareId.substring(0, 8)}...\``, inline: true }
        )
        .setTimestamp();

      if (result.success && result.key) {
        embed.addFields(
          { name: 'Expires', value: new Date(result.key.expiresAt).toLocaleDateString(), inline: true },
          { name: 'Uses', value: `${result.key.currentUses}/${result.key.maxUses}`, inline: true }
        );
      }

      await interaction.reply({ embeds: [embed], ephemeral: true });

      // Log the result
      await storage.createDiscordLog({
        action: 'KEY_REDEEM_RESULT',
        discordUserId,
        discordUsername,
        keyValue: key,
        details: result.message,
        success: result.success
      });

      // Send webhook notification if configured
      if (this.config.webhookUrl && result.success) {
        await this.sendWebhookNotification(result, discordUserId, discordUsername, key);
      }

    } catch (error) {
      console.error('Discord redeem error:', error);
      await interaction.reply({
        content: '❌ An error occurred while processing your request. Please try again later.',
        ephemeral: true
      });
    }
  }

  private async handleStatusCommand(interaction: any) {
    const discordUserId = interaction.user.id;
    const discordUsername = interaction.user.username;

    try {
      const keys = await storage.getAllKeys();
      const userKeys = keys.filter(k => k.discordUserId === discordUserId);

      const embed = new EmbedBuilder()
        .setColor(0x0099ff)
        .setTitle('📊 Your Key Status')
        .setDescription(`Status for <@${discordUserId}>`)
        .addFields(
          { name: 'Total Keys', value: userKeys.length.toString(), inline: true },
          { name: 'Active', value: userKeys.filter(k => k.isRedeemed && new Date(k.expiresAt) > new Date()).length.toString(), inline: true },
          { name: 'Expired', value: userKeys.filter(k => new Date(k.expiresAt) <= new Date()).length.toString(), inline: true }
        )
        .setTimestamp();

      if (userKeys.length > 0) {
        const keyList = userKeys.slice(0, 5).map(k => {
          const status = new Date(k.expiresAt) <= new Date() ? '🔴 Expired' : 
                       k.isRedeemed ? '🟢 Active' : '🟡 Unused';
          return `\`${k.key}\` - ${status}`;
        }).join('\n');

        embed.addFields({ name: 'Recent Keys', value: keyList, inline: false });
      }

      await interaction.reply({ embeds: [embed], ephemeral: true });

      // Log the status check
      await storage.createDiscordLog({
        action: 'STATUS_CHECK',
        discordUserId,
        discordUsername,
        keyValue: null,
        details: `User checked their status - ${userKeys.length} keys found`,
        success: true
      });

    } catch (error) {
      console.error('Discord status error:', error);
      await interaction.reply({
        content: '❌ An error occurred while checking your status.',
        ephemeral: true
      });
    }
  }

  private async sendWebhookNotification(result: any, discordUserId: string, discordUsername: string, key: string) {
    if (!this.config.webhookUrl) return;

    const embed = {
      title: '🎉 New Key Redemption',
      color: 0x00ff00,
      fields: [
        { name: 'User', value: `<@${discordUserId}> (${discordUsername})`, inline: true },
        { name: 'Key', value: `\`${key}\``, inline: true },
        { name: 'Time', value: new Date().toLocaleString(), inline: true }
      ],
      timestamp: new Date().toISOString()
    };

    try {
      const response = await fetch(this.config.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ embeds: [embed] })
      });

      if (!response.ok) {
        console.error('Webhook notification failed:', response.statusText);
      }
    } catch (error) {
      console.error('Webhook error:', error);
    }
  }

  async start() {
    if (!this.config.token) {
      console.log('⚠️  Discord bot token not provided - Discord features disabled');
      return false;
    }

    try {
      await this.client.login(this.config.token);
      return true;
    } catch (error) {
      console.error('❌ Failed to start Discord bot:', error);
      return false;
    }
  }

  async stop() {
    if (this.client) {
      this.client.destroy();
    }
  }
}

export async function initializeDiscordBot() {
  if (isInitialized) return client;

  const config: DiscordConfig = {
    token: process.env.DISCORD_BOT_TOKEN,
    guildId: process.env.DISCORD_GUILD_ID,
    channelId: process.env.DISCORD_CHANNEL_ID,
    webhookUrl: process.env.DISCORD_WEBHOOK_URL,
  };

  const bot = new DiscordBot(config);
  const started = await bot.start();

  if (started) {
    client = bot.client;
    isInitialized = true;
    console.log('✅ Discord bot initialized successfully');
  }

  return client;
}

// Export for external webhook usage
export async function sendDiscordWebhook(webhookUrl: string, embed: any) {
  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ embeds: [embed] })
    });

    return response.ok;
  } catch (error) {
    console.error('Discord webhook error:', error);
    return false;
  }
}