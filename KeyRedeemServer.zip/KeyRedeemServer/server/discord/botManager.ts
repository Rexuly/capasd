import { spawn, ChildProcess } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';
import { EventEmitter } from 'events';
import { randomUUID } from 'crypto';

export interface BotInstance {
  id: string;
  fileName: string;
  language: string;
  process: ChildProcess | null;
  status: 'starting' | 'running' | 'stopped' | 'error' | 'crashed';
  pid?: number;
  startTime?: Date;
  lastError?: string;
  logs: BotLog[];
  port?: number;
}

export interface BotLog {
  id: string;
  timestamp: Date;
  level: 'info' | 'warn' | 'error' | 'debug';
  message: string;
  source: 'stdout' | 'stderr' | 'system';
}

export class DiscordBotManager extends EventEmitter {
  private bots: Map<string, BotInstance> = new Map();
  private tempDir = path.join(process.cwd(), 'temp', 'bots');
  private maxLogs = 500; // Keep last 500 logs per bot

  constructor() {
    super();
    this.ensureTempDir();
  }

  private async ensureTempDir() {
    try {
      await fs.mkdir(this.tempDir, { recursive: true });
    } catch (error) {
      console.error('Failed to create temp directory:', error);
    }
  }

  private addLog(botId: string, level: BotLog['level'], message: string, source: BotLog['source'] = 'system') {
    const bot = this.bots.get(botId);
    if (!bot) return;

    const log: BotLog = {
      id: randomUUID(),
      timestamp: new Date(),
      level,
      message: message.trim(),
      source
    };

    bot.logs.push(log);
    
    // Keep only the last maxLogs entries
    if (bot.logs.length > this.maxLogs) {
      bot.logs = bot.logs.slice(-this.maxLogs);
    }

    // Emit log event for real-time updates
    this.emit('log', { botId, log });
  }

  private async writeCodeToFile(botId: string, fileName: string, code: string, language: string): Promise<string> {
    const extension = language === 'python' ? '.py' : '.js';
    const safeFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
    const filePath = path.join(this.tempDir, `${botId}_${safeFileName}${extension}`);
    
    try {
      await fs.writeFile(filePath, code, 'utf8');
      return filePath;
    } catch (error) {
      throw new Error(`Failed to write bot code to file: ${error}`);
    }
  }

  private setupProcessHandlers(bot: BotInstance) {
    if (!bot.process) return;

    bot.process.stdout?.on('data', (data: Buffer) => {
      const message = data.toString();
      this.addLog(bot.id, 'info', message, 'stdout');
      
      // Check for Discord.js ready event
      if (message.includes('Discord bot is ready') || message.includes('logged in as') || message.includes('connected to Discord') || message.includes('Ready!') || message.includes('has connected to Discord!')) {
        bot.status = 'running';
        this.emit('statusChange', { botId: bot.id, status: 'running' });
      }
    });

    bot.process.stderr?.on('data', (data: Buffer) => {
      const message = data.toString();
      this.addLog(bot.id, 'error', message, 'stderr');
      
      // Update bot status if there's a critical error
      if (message.toLowerCase().includes('error') || message.toLowerCase().includes('failed')) {
        bot.lastError = message;
        if (bot.status === 'starting') {
          bot.status = 'error';
          this.emit('statusChange', { botId: bot.id, status: 'error' });
        }
      }
    });

    bot.process.on('spawn', () => {
      bot.pid = bot.process?.pid;
      bot.startTime = new Date();
      this.addLog(bot.id, 'info', `Bot process started with PID: ${bot.pid}`);
      this.emit('statusChange', { botId: bot.id, status: 'starting' });
    });

    bot.process.on('exit', (code, signal) => {
      this.addLog(bot.id, code === 0 ? 'info' : 'error', 
        `Bot process exited with code ${code} and signal ${signal}`);
      
      bot.status = code === 0 ? 'stopped' : 'crashed';
      bot.process = null;
      bot.pid = undefined;
      
      this.emit('statusChange', { botId: bot.id, status: bot.status });
    });

    bot.process.on('error', (error) => {
      this.addLog(bot.id, 'error', `Process error: ${error.message}`);
      bot.status = 'error';
      bot.lastError = error.message;
      this.emit('statusChange', { botId: bot.id, status: 'error' });
    });
  }

  async startBot(botId: string, fileName: string, code: string, language: string): Promise<void> {
    try {
      // Stop existing bot if running
      if (this.bots.has(botId)) {
        await this.stopBot(botId);
      }

      // Create new bot instance
      const bot: BotInstance = {
        id: botId,
        fileName,
        language,
        process: null,
        status: 'starting',
        logs: []
      };

      this.bots.set(botId, bot);
      this.addLog(botId, 'info', `Starting ${language} bot: ${fileName}`);

      // Write code to temporary file
      const filePath = await this.writeCodeToFile(botId, fileName, code, language);
      this.addLog(botId, 'info', `Code written to: ${filePath}`);

      // Prepare environment variables
      const env = {
        ...process.env,
        NODE_ENV: 'production',
        BOT_ID: botId,
        BOT_NAME: fileName,
        DISCORD_BOT_TOKEN: process.env.DISCORD_BOT_TOKEN || '',
        DISCORD_GUILD_ID: process.env.DISCORD_GUILD_ID || '',
        DISCORD_CHANNEL_ID: process.env.DISCORD_CHANNEL_ID || ''
      };

      let command: string;
      let args: string[];

      if (language === 'python') {
        // Check if discord.py is available
        command = 'python3';
        args = ['-c', 'import discord; print("discord.py available")'];
        
        try {
          await new Promise((resolve, reject) => {
            const checkProcess = spawn(command, args);
            checkProcess.on('exit', (code) => {
              if (code === 0) resolve(void 0);
              else reject(new Error('discord.py not installed'));
            });
            checkProcess.on('error', reject);
          });
          
          command = 'python3';
          args = [filePath];
        } catch (error) {
          throw new Error('Python discord.py library not found. Please install with: pip install discord.py');
        }
      } else {
        // JavaScript/TypeScript
        command = 'node';
        args = [filePath];
      }

      this.addLog(botId, 'info', `Executing: ${command} ${args.join(' ')}`);

      // Start the bot process
      bot.process = spawn(command, args, {
        env,
        cwd: this.tempDir,
        stdio: ['pipe', 'pipe', 'pipe']
      });

      // Setup process handlers
      this.setupProcessHandlers(bot);

      this.addLog(botId, 'info', 'Bot startup initiated');

    } catch (error) {
      const bot = this.bots.get(botId);
      if (bot) {
        bot.status = 'error';
        bot.lastError = error instanceof Error ? error.message : 'Unknown error';
        this.addLog(botId, 'error', `Failed to start bot: ${bot.lastError}`);
        this.emit('statusChange', { botId, status: 'error' });
      }
      throw error;
    }
  }

  async stopBot(botId: string): Promise<void> {
    const bot = this.bots.get(botId);
    if (!bot || !bot.process) return;

    this.addLog(botId, 'info', 'Stopping bot...');

    try {
      // Try graceful shutdown first
      bot.process.kill('SIGTERM');
      
      // Wait a bit for graceful shutdown
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Force kill if still running
      if (bot.process && !bot.process.killed) {
        bot.process.kill('SIGKILL');
        this.addLog(botId, 'warn', 'Bot force-killed (SIGKILL)');
      }
    } catch (error) {
      this.addLog(botId, 'error', `Error stopping bot: ${error}`);
    }

    bot.status = 'stopped';
    bot.process = null;
    bot.pid = undefined;
    
    this.emit('statusChange', { botId, status: 'stopped' });
  }

  async restartBot(botId: string, fileName: string, code: string, language: string): Promise<void> {
    this.addLog(botId, 'info', 'Restarting bot...');
    await this.stopBot(botId);
    await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
    await this.startBot(botId, fileName, code, language);
  }

  getBotStatus(botId: string): BotInstance | undefined {
    return this.bots.get(botId);
  }

  getAllBots(): BotInstance[] {
    return Array.from(this.bots.values());
  }

  getBotLogs(botId: string, limit?: number): BotLog[] {
    const bot = this.bots.get(botId);
    if (!bot) return [];
    
    const logs = bot.logs;
    return limit ? logs.slice(-limit) : logs;
  }

  clearBotLogs(botId: string): void {
    const bot = this.bots.get(botId);
    if (bot) {
      bot.logs = [];
      this.addLog(botId, 'info', 'Logs cleared');
    }
  }

  async cleanup(): Promise<void> {
    // Stop all running bots
    const stopPromises = Array.from(this.bots.keys()).map(botId => this.stopBot(botId));
    await Promise.all(stopPromises);

    // Clean up temporary files
    try {
      const files = await fs.readdir(this.tempDir);
      const deletePromises = files.map(file => 
        fs.unlink(path.join(this.tempDir, file)).catch(() => {})
      );
      await Promise.all(deletePromises);
    } catch (error) {
      console.error('Error cleaning up temp files:', error);
    }
  }
}

// Singleton instance
export const botManager = new DiscordBotManager();

// Cleanup on process exit
process.on('exit', () => {
  botManager.cleanup();
});

process.on('SIGINT', () => {
  botManager.cleanup().then(() => process.exit(0));
});

process.on('SIGTERM', () => {
  botManager.cleanup().then(() => process.exit(0));
});