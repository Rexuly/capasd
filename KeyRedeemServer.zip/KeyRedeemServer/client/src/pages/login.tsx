import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface LoginProps {
  onLogin: (token: string, admin: any) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [credentials, setCredentials] = useState({
    username: "",
    password: ""
  });
  
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async (data: { username: string; password: string }) => {
      const response = await apiRequest("POST", "/api/login", data);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('admin_info', JSON.stringify(data.admin));
        onLogin(data.token, data.admin);
        toast({
          title: "Login Successful",
          description: `Welcome back, ${data.admin.username}!`,
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!credentials.username.trim() || !credentials.password.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter both username and password",
        variant: "destructive",
      });
      return;
    }
    
    loginMutation.mutate(credentials);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="mx-auto h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <i className="fas fa-shield-alt text-primary text-2xl"></i>
          </div>
          <h2 className="text-3xl font-bold text-foreground">Admin Login</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Sign in to access the key management system
          </p>
        </div>

        {/* Login Form */}
        <Card className="mt-8 bg-card border-border">
          <CardHeader>
            <CardTitle className="text-center text-lg font-medium text-foreground">
              Administrator Access
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="username" className="block text-sm font-medium text-foreground">
                  Username
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={credentials.username}
                  onChange={(e) => setCredentials(prev => ({ ...prev, username: e.target.value }))}
                  className="mt-1 w-full bg-input border-border text-foreground"
                  placeholder="Enter your username"
                  required
                  data-testid="input-username"
                />
              </div>

              <div>
                <Label htmlFor="password" className="block text-sm font-medium text-foreground">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={credentials.password}
                  onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                  className="mt-1 w-full bg-input border-border text-foreground"
                  placeholder="Enter your password"
                  required
                  data-testid="input-password"
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90"
                disabled={loginMutation.isPending}
                data-testid="button-login"
              >
                {loginMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Signing in...
                  </>
                ) : (
                  <>
                    <i className="fas fa-sign-in-alt mr-2"></i>
                    Sign In
                  </>
                )}
              </Button>
            </form>


          </CardContent>
        </Card>

        {/* Discord Bot Status */}
        <Card className="mt-4 bg-card border-border">
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-sm font-medium text-foreground mb-2">Discord Integration</h3>
              <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                <i className="fab fa-discord text-primary"></i>
                <span>Bot ready for key redemptions</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Users can redeem keys directly through Discord commands
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}