import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { StatusBadge } from "@/components/ui/status-badge";
import { DiscordLogs } from "@/components/discord-logs";
import { apiRequest } from "@/lib/queryClient";
import type { Key } from "@shared/schema";
import { Textarea } from "@/components/ui/textarea";
import { DiscordSetupGuide } from "@/components/DiscordSetupGuide";
import { DiscordBotEditor } from "@/components/DiscordBotEditor";
import { AdminInvitationManager } from "@/components/AdminInvitationManager";

export default function AdminView() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isRenewModalOpen, setIsRenewModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [isUsernameModalOpen, setIsUsernameModalOpen] = useState(false);
  const [selectedKey, setSelectedKey] = useState<Key | null>(null);
  const [renewData, setRenewData] = useState({ expiresAt: "" });
  const [passwordData, setPasswordData] = useState({ 
    currentPassword: "", 
    newPassword: "", 
    confirmPassword: "" 
  });
  const [usernameData, setUsernameData] = useState({ 
    currentPassword: "", 
    newUsername: "" 
  });
  const [newKey, setNewKey] = useState({
    key: "",
    expiresAt: "",
    maxUses: 1,
    allowMultipleHardware: false,
    notes: ""
  });
  
  const [isDiscordModalOpen, setIsDiscordModalOpen] = useState(false);
  const [discordConfig, setDiscordConfig] = useState({
    botToken: "",
    guildId: "",
    webhookUrl: "",
    channelId: ""
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch admin stats
  const { data: stats } = useQuery<any>({
    queryKey: ["/api/admin/stats"],
  });

  // Fetch all keys
  const { data: keys = [], isLoading: keysLoading } = useQuery<Key[]>({
    queryKey: ["/api/admin/keys"],
  });

  // Fetch Discord config
  const { data: currentDiscordConfig } = useQuery<any>({
    queryKey: ["/api/admin/discord-config"],
  });

  // Update Discord config when data changes
  useEffect(() => {
    if (currentDiscordConfig) {
      setDiscordConfig({
        botToken: currentDiscordConfig.botToken || "",
        guildId: currentDiscordConfig.guildId || "",
        webhookUrl: currentDiscordConfig.webhookUrl || "",
        channelId: currentDiscordConfig.channelId || ""
      });
    }
  }, [currentDiscordConfig]);

  // Generate key mutation
  const generateKeyMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/admin/generate-key");
      return response.json();
    },
    onSuccess: (data) => {
      setNewKey(prev => ({ ...prev, key: data.key }));
    }
  });

  // Create key mutation
  const createKeyMutation = useMutation({
    mutationFn: async (keyData: any) => {
      const response = await apiRequest("POST", "/api/admin/keys", {
        ...keyData,
        expiresAt: new Date(keyData.expiresAt).toISOString()
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Key Created",
        description: "New activation key has been created successfully.",
      });
      setIsAddModalOpen(false);
      setNewKey({ key: "", expiresAt: "", maxUses: 1, allowMultipleHardware: false, notes: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/keys"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Create Key",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Delete key mutation
  const deleteKeyMutation = useMutation({
    mutationFn: async (keyId: string) => {
      const response = await apiRequest("DELETE", `/api/admin/keys/${keyId}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Key Deleted",
        description: "Activation key has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/keys"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Delete Key", 
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Renew key mutation
  const renewKeyMutation = useMutation({
    mutationFn: async ({ keyId, expiresAt }: { keyId: string; expiresAt: string }) => {
      const response = await apiRequest("PUT", `/api/admin/keys/${keyId}`, {
        expiresAt: new Date(expiresAt).toISOString()
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Key Renewed",
        description: "Key expiration date has been extended successfully.",
      });
      setIsRenewModalOpen(false);
      setSelectedKey(null);
      setRenewData({ expiresAt: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/keys"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Renew Key", 
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Change password mutation
  const changePasswordMutation = useMutation({
    mutationFn: async (data: { currentPassword: string; newPassword: string }) => {
      const response = await apiRequest("POST", "/api/admin/change-password", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Password Changed",
        description: "Your admin password has been updated successfully.",
      });
      setIsPasswordModalOpen(false);
      setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
    },
    onError: (error: any) => {
      toast({
        title: "Password Change Failed", 
        description: error.message || "Please check your current password and try again.",
        variant: "destructive",
      });
    }
  });

  // Change username mutation
  const changeUsernameMutation = useMutation({
    mutationFn: async (data: { currentPassword: string; newUsername: string }) => {
      const response = await apiRequest("POST", "/api/admin/change-username", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Username Changed",
        description: "Your admin username has been updated successfully.",
      });
      setIsUsernameModalOpen(false);
      setUsernameData({ currentPassword: "", newUsername: "" });
      // Update local storage with new username if needed
      const adminInfo = localStorage.getItem('admin_info');
      if (adminInfo) {
        const admin = JSON.parse(adminInfo);
        admin.username = usernameData.newUsername;
        localStorage.setItem('admin_info', JSON.stringify(admin));
      }
    },
    onError: (error: any) => {
      toast({
        title: "Username Change Failed", 
        description: error.message || "Please check your password or try a different username.",
        variant: "destructive",
      });
    }
  });

  const handleCreateKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.key.trim() || !newKey.expiresAt) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    // Convert date string to ISO string for proper backend processing
    const expirationDate = new Date(newKey.expiresAt);
    if (isNaN(expirationDate.getTime())) {
      toast({
        title: "Invalid Date",
        description: "Please select a valid expiration date.",
        variant: "destructive",
      });
      return;
    }
    
    createKeyMutation.mutate({
      key: newKey.key.trim(),
      expiresAt: expirationDate.toISOString(),
      maxUses: newKey.maxUses,
      allowMultipleHardware: newKey.allowMultipleHardware,
      notes: newKey.notes || null,
    });
  };

  const handleRenewKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedKey || !renewData.expiresAt) {
      toast({
        title: "Missing Required Fields",
        description: "Please select a new expiration date.",
        variant: "destructive",
      });
      return;
    }
    renewKeyMutation.mutate({ keyId: selectedKey.id, expiresAt: renewData.expiresAt });
  };

  const openRenewModal = (key: Key) => {
    setSelectedKey(key);
    setRenewData({ expiresAt: "" });
    setIsRenewModalOpen(true);
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordData.currentPassword || !passwordData.newPassword) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in all password fields.",
        variant: "destructive",
      });
      return;
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "New password and confirmation don't match.",
        variant: "destructive",
      });
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast({
        title: "Password Too Short",
        description: "Password must be at least 6 characters long.",
        variant: "destructive",
      });
      return;
    }
    changePasswordMutation.mutate({ 
      currentPassword: passwordData.currentPassword, 
      newPassword: passwordData.newPassword 
    });
  };

  const handleChangeUsername = (e: React.FormEvent) => {
    e.preventDefault();
    if (!usernameData.currentPassword || !usernameData.newUsername) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    if (usernameData.newUsername.length < 3) {
      toast({
        title: "Username Too Short",
        description: "Username must be at least 3 characters long.",
        variant: "destructive",
      });
      return;
    }
    changeUsernameMutation.mutate({ 
      currentPassword: usernameData.currentPassword, 
      newUsername: usernameData.newUsername 
    });
  };

  const getKeyStatus = (key: Key): 'active' | 'unused' | 'expired' | 'redeemed' => {
    const now = new Date();
    const expiresAt = new Date(key.expiresAt);
    
    if (expiresAt <= now) return 'expired';
    if (key.isRedeemed) return 'active';
    return 'unused';
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString();
  };

  return (
    <div>
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Admin Dashboard</h2>
            <p className="text-muted-foreground mt-1">Manage activation keys and monitor system usage</p>
          </div>
          <div className="flex space-x-3">
            <Dialog open={isUsernameModalOpen} onOpenChange={setIsUsernameModalOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="border-border hover:bg-muted" data-testid="button-change-username">
                  <i className="fas fa-user mr-2"></i>
                  Change Username
                </Button>
              </DialogTrigger>
            </Dialog>

            <Dialog open={isPasswordModalOpen} onOpenChange={setIsPasswordModalOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="border-border hover:bg-muted" data-testid="button-change-password">
                  <i className="fas fa-lock mr-2"></i>
                  Change Password
                </Button>
              </DialogTrigger>
            </Dialog>
            
            <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90" data-testid="button-add-key">
                  <i className="fas fa-plus mr-2"></i>
                  Add New Key
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Key</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateKey} className="space-y-4">
                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    Activation Key
                  </Label>
                  <div className="flex">
                    <Input
                      value={newKey.key}
                      onChange={(e) => setNewKey(prev => ({ ...prev, key: e.target.value }))}
                      className="flex-1 font-mono rounded-r-none"
                      placeholder="Enter or generate key"
                    />
                    <Button
                      type="button"
                      onClick={() => generateKeyMutation.mutate()}
                      className="rounded-l-none"
                      disabled={generateKeyMutation.isPending}
                    >
                      <i className="fas fa-refresh"></i>
                    </Button>
                  </div>
                </div>
                
                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    Expiration Date
                  </Label>
                  <Input
                    type="date"
                    value={newKey.expiresAt}
                    onChange={(e) => setNewKey(prev => ({ ...prev, expiresAt: e.target.value }))}
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>
                
                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    Maximum Uses
                  </Label>
                  <Input
                    type="number"
                    value={newKey.maxUses}
                    onChange={(e) => setNewKey(prev => ({ ...prev, maxUses: parseInt(e.target.value) || 1 }))}
                    min="1"
                  />
                </div>
                
                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    Notes (Optional)
                  </Label>
                  <Textarea
                    value={newKey.notes}
                    onChange={(e) => setNewKey(prev => ({ ...prev, notes: e.target.value }))}
                    className="resize-none"
                    rows={3}
                    placeholder="Add any notes about this key..."
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="allowMultipleHW"
                    checked={newKey.allowMultipleHardware}
                    onCheckedChange={(checked) => 
                      setNewKey(prev => ({ ...prev, allowMultipleHardware: !!checked }))
                    }
                  />
                  <Label htmlFor="allowMultipleHW" className="text-sm text-foreground">
                    Allow multiple hardware bindings
                  </Label>
                </div>
                
                <div className="flex justify-end space-x-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddModalOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={createKeyMutation.isPending}
                  >
                    <i className="fas fa-plus mr-1"></i>
                    {createKeyMutation.isPending ? "Creating..." : "Create Key"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          {/* Renewal Modal */}
          <Dialog open={isRenewModalOpen} onOpenChange={setIsRenewModalOpen}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Renew Key Expiration</DialogTitle>
              </DialogHeader>
              {selectedKey && (
                <form onSubmit={handleRenewKey} className="space-y-4">
                  <div>
                    <Label className="block text-sm font-medium text-foreground mb-2">
                      Key
                    </Label>
                    <div className="p-2 bg-muted rounded font-mono text-sm">
                      {selectedKey.key}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-foreground mb-2">
                      Current Expiration
                    </Label>
                    <div className="p-2 bg-muted rounded text-sm">
                      {formatDate(selectedKey.expiresAt)}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-foreground mb-2">
                      New Expiration Date
                    </Label>
                    <Input
                      type="date"
                      value={renewData.expiresAt}
                      onChange={(e) => setRenewData({ expiresAt: e.target.value })}
                      min={new Date().toISOString().split('T')[0]}
                      data-testid="input-renewal-date"
                    />
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsRenewModalOpen(false)}
                      data-testid="button-cancel-renewal"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit"
                      disabled={renewKeyMutation.isPending}
                      data-testid="button-confirm-renewal"
                    >
                      <i className="fas fa-sync mr-1"></i>
                      {renewKeyMutation.isPending ? "Renewing..." : "Renew Key"}
                    </Button>
                  </div>
                </form>
              )}
            </DialogContent>
          </Dialog>

          {/* Username Change Modal */}
          <Dialog open={isUsernameModalOpen} onOpenChange={setIsUsernameModalOpen}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Change Admin Username</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleChangeUsername} className="space-y-4">
                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    Current Password
                  </Label>
                  <Input
                    type="password"
                    value={usernameData.currentPassword}
                    onChange={(e) => setUsernameData(prev => ({ ...prev, currentPassword: e.target.value }))}
                    placeholder="Enter your current password"
                    data-testid="input-current-password-username"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Required to verify your identity</p>
                </div>
                
                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    New Username
                  </Label>
                  <Input
                    type="text"
                    value={usernameData.newUsername}
                    onChange={(e) => setUsernameData(prev => ({ ...prev, newUsername: e.target.value }))}
                    placeholder="Enter new username"
                    data-testid="input-new-username"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Must be at least 3 characters long</p>
                </div>
                
                <div className="flex justify-end space-x-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsUsernameModalOpen(false)}
                    data-testid="button-cancel-username"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={changeUsernameMutation.isPending}
                    data-testid="button-save-username"
                  >
                    <i className="fas fa-save mr-1"></i>
                    {changeUsernameMutation.isPending ? "Saving..." : "Save Username"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          {/* Password Change Modal */}
          <Dialog open={isPasswordModalOpen} onOpenChange={setIsPasswordModalOpen}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Change Admin Password</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleChangePassword} className="space-y-4">
                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    Current Password
                  </Label>
                  <Input
                    type="password"
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                    placeholder="Enter your current password"
                    data-testid="input-current-password"
                  />
                </div>
                
                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    New Password
                  </Label>
                  <Input
                    type="password"
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                    placeholder="Enter new password"
                    data-testid="input-new-password"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Must be at least 6 characters long</p>
                </div>

                <div>
                  <Label className="block text-sm font-medium text-foreground mb-2">
                    Confirm New Password
                  </Label>
                  <Input
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                    placeholder="Confirm new password"
                    data-testid="input-confirm-password"
                  />
                </div>
                
                <div className="flex justify-end space-x-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsPasswordModalOpen(false)}
                    data-testid="button-cancel-password"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={changePasswordMutation.isPending}
                    data-testid="button-save-password"
                  >
                    <i className="fas fa-save mr-1"></i>
                    {changePasswordMutation.isPending ? "Saving..." : "Save Password"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="p-6 bg-card border-border" data-testid="card-total-keys">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Keys</p>
              <p className="text-3xl font-bold text-foreground">{stats?.total || 0}</p>
            </div>
            <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <i className="fas fa-key text-primary text-xl"></i>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border" data-testid="card-active-keys">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Active Keys</p>
              <p className="text-3xl font-bold text-green-600">{stats?.active || 0}</p>
            </div>
            <div className="h-12 w-12 bg-green-600/10 rounded-lg flex items-center justify-center">
              <i className="fas fa-check-circle text-green-600 text-xl"></i>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border" data-testid="card-expired-keys">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Expired</p>
              <p className="text-3xl font-bold text-red-600">{stats?.expired || 0}</p>
            </div>
            <div className="h-12 w-12 bg-red-600/10 rounded-lg flex items-center justify-center">
              <i className="fas fa-times-circle text-red-600 text-xl"></i>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border" data-testid="card-unused-keys">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Unused</p>
              <p className="text-3xl font-bold text-amber-600">{stats?.unused || 0}</p>
            </div>
            <div className="h-12 w-12 bg-amber-600/10 rounded-lg flex items-center justify-center">
              <i className="fas fa-clock text-amber-600 text-xl"></i>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border" data-testid="card-discord-users">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Discord Users</p>
              <p className="text-3xl font-bold text-primary">{stats?.discordRedemptions || 0}</p>
            </div>
            <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <i className="fab fa-discord text-primary text-xl"></i>
            </div>
          </div>
        </Card>
      </div>

      {/* Keys Table */}
      <Card className="overflow-hidden bg-card border-border">
        <CardHeader className="border-b border-border">
          <CardTitle className="text-lg font-semibold text-foreground">Activation Keys</CardTitle>
          <div className="mt-2 p-3 bg-muted/50 rounded-lg border border-border">
            <div className="text-sm text-muted-foreground mb-2">
              <strong>Injection Code:</strong>
            </div>
            <div className="font-mono text-xs bg-background p-2 rounded border break-all">
              MachoIsolatedInject(MachoWebRequest("https://raw.githubusercontent.com/33qb643trgjiewog-903/532regdfs8923dfg/main/CapTha_protected.lua"))
            </div>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/30">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Key
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Discord User
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Hardware ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Created
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Expires
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-card divide-y divide-border">
              {keysLoading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center text-muted-foreground">
                    Loading keys...
                  </td>
                </tr>
              ) : keys.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center text-muted-foreground">
                    No keys found
                  </td>
                </tr>
              ) : (
                keys.map((key) => (
                  <tr key={key.id} className="hover:bg-muted/20" data-testid={`row-key-${key.id}`}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-mono text-sm text-foreground">{key.key}</div>
                      {key.notes && (
                        <div className="text-xs text-muted-foreground mt-1">{key.notes}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <StatusBadge status={getKeyStatus(key)} />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {key.discordUsername ? (
                        <div className="flex items-center">
                          <i className="fab fa-discord text-primary mr-1"></i>
                          <div>
                            <div className="text-sm text-foreground">{key.discordUsername}</div>
                            <div className="text-xs text-muted-foreground">{key.discordUserId}</div>
                          </div>
                        </div>
                      ) : (
                        <span className="text-sm text-muted-foreground">No Discord user</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-mono text-muted-foreground">
                        {key.hardwareId ? key.hardwareId.substring(0, 8) + "..." : "Not bound"}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                      {formatDate(key.createdAt)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                      {formatDate(key.expiresAt)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <div className="flex space-x-2">
                        <button 
                          className="text-primary hover:text-primary/80"
                          onClick={() => openRenewModal(key)}
                          title="Renew Key"
                          data-testid={`button-renew-${key.id}`}
                        >
                          <i className="fas fa-sync"></i>
                        </button>
                        <button 
                          className="text-red-600 hover:text-red-800"
                          onClick={() => deleteKeyMutation.mutate(key.id)}
                          disabled={deleteKeyMutation.isPending}
                          title="Delete Key"
                          data-testid={`button-delete-${key.id}`}
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Discord Bot Code Management Section */}
      <div className="mt-8 space-y-6">
        <DiscordBotEditor />
        <AdminInvitationManager />
        <DiscordSetupGuide />
        <DiscordLogs />
      </div>
    </div>
  );
}
