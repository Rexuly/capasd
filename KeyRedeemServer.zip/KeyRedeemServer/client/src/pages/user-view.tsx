import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { generateClientHardwareId, formatHardwareId } from "@/lib/hardware";
import { apiRequest } from "@/lib/queryClient";

export default function UserView() {
  const [keyInput, setKeyInput] = useState("");
  const [discordUserId, setDiscordUserId] = useState("");
  const [discordUsername, setDiscordUsername] = useState("");
  const [showDiscordFields, setShowDiscordFields] = useState(false);
  const { toast } = useToast();
  
  const hardwareId = generateClientHardwareId();

  // Query to get user's key status based on hardware ID
  const { data: userKeyStatus, refetch: refetchKeyStatus } = useQuery({
    queryKey: ['/api/user-status', hardwareId],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/user-status?hardwareId=${hardwareId}`);
      return response.json();
    },
  });

  const redeemMutation = useMutation({
    mutationFn: async ({ key, hardwareId, discordUserId, discordUsername }: { 
      key: string; 
      hardwareId: string; 
      discordUserId?: string; 
      discordUsername?: string; 
    }) => {
      const response = await apiRequest("POST", "/api/redeem", { 
        key, 
        hardwareId,
        discordUserId: discordUserId || undefined,
        discordUsername: discordUsername || undefined
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Key Redeemed Successfully!",
          description: "Your access has been activated on this machine.",
        });
        setKeyInput("");
        setDiscordUserId("");
        setDiscordUsername("");
        refetchKeyStatus();
      }
    },
    onError: (error: any) => {
      const message = error.message || "Failed to redeem key";
      toast({
        title: "Redemption Failed",
        description: message,
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyInput.trim()) {
      toast({
        title: "Key Required",
        description: "Please enter an activation key",
        variant: "destructive",
      });
      return;
    }
    
    redeemMutation.mutate({ 
      key: keyInput.trim().toUpperCase(), 
      hardwareId,
      discordUserId: showDiscordFields ? discordUserId : undefined,
      discordUsername: showDiscordFields ? discordUsername : undefined
    });
  };

  return (
    <div className="max-w-2xl mx-auto">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <div className="mx-auto h-24 w-24 bg-primary/10 rounded-full flex items-center justify-center mb-6">
          <i className="fas fa-key text-primary text-3xl"></i>
        </div>
        <h2 className="text-3xl font-bold text-foreground mb-4">Redeem Your Key</h2>
        <p className="text-lg text-muted-foreground">Enter your activation key below to unlock your access</p>
      </div>

      {/* Key Redemption Form */}
      <Card className="p-8 bg-card border-border">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="activationKey" className="block text-sm font-medium text-foreground mb-2">
              Activation Key <span className="text-red-500">*</span>
            </Label>
            <div className="relative">
              <Input
                type="text"
                id="activationKey"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                className="w-full px-4 py-3 text-lg font-mono tracking-wider pr-10 bg-input border-border text-foreground"
                placeholder="XXXX-XXXX-XXXX-XXXX"
                data-testid="input-activation-key"
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                <i className="fas fa-key text-muted-foreground"></i>
              </div>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">Enter the activation key provided to you</p>
          </div>

          {/* Discord Connection Toggle */}
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="connectDiscord"
              checked={showDiscordFields}
              onChange={(e) => setShowDiscordFields(e.target.checked)}
              className="w-4 h-4 text-primary bg-input border-border rounded focus:ring-primary"
            />
            <Label htmlFor="connectDiscord" className="text-sm text-foreground">
              Connect Discord Account (Optional)
            </Label>
          </div>

          {/* Discord Fields */}
          {showDiscordFields && (
            <div className="space-y-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
              <div>
                <Label htmlFor="discordUserId" className="block text-sm font-medium text-foreground mb-2">
                  Discord User ID
                </Label>
                <Input
                  type="text"
                  id="discordUserId"
                  value={discordUserId}
                  onChange={(e) => setDiscordUserId(e.target.value)}
                  className="bg-input border-border text-foreground"
                  placeholder="123456789012345678"
                  data-testid="input-discord-user-id"
                />
                <p className="mt-1 text-xs text-muted-foreground">Enable Developer Mode, right-click your profile, Copy User ID</p>
              </div>
              
              <div>
                <Label htmlFor="discordUsername" className="block text-sm font-medium text-foreground mb-2">
                  Discord Username
                </Label>
                <Input
                  type="text"
                  id="discordUsername"
                  value={discordUsername}
                  onChange={(e) => setDiscordUsername(e.target.value)}
                  className="bg-input border-border text-foreground"
                  placeholder="username#1234"
                  data-testid="input-discord-username"
                />
                <p className="mt-1 text-xs text-muted-foreground">Your Discord username with discriminator (e.g. user#1234)</p>
              </div>
            </div>
          )}

          {/* Hardware ID Display */}
          <div className="bg-muted/30 rounded-lg p-4 border border-border">
            <h4 className="text-sm font-medium text-foreground mb-2">Hardware Information</h4>
            <div className="text-sm text-muted-foreground">
              <div className="flex justify-between items-center mb-1">
                <span>Hardware ID:</span>
                <span className="font-mono text-xs bg-background px-2 py-1 rounded border border-border">
                  {formatHardwareId(hardwareId)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span>Machine:</span>
                <span className="text-xs">{navigator.platform}</span>
              </div>
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-primary hover:bg-primary/90 py-3"
            disabled={redeemMutation.isPending}
            data-testid="button-redeem-key"
          >
            <i className="fas fa-unlock-alt mr-2"></i>
            {redeemMutation.isPending ? "Redeeming..." : "Redeem Key"}
          </Button>
        </form>
      </Card>

      {/* Key Status Display */}
      <Card className="mt-8 p-6 bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">Key Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-muted/20 rounded-lg border border-border" data-testid="status-keys-redeemed">
              <div className="text-2xl font-bold text-muted-foreground">
                {userKeyStatus?.keysRedeemed || 0}
              </div>
              <div className="text-sm text-muted-foreground">Keys Redeemed</div>
            </div>
            <div className="text-center p-4 bg-primary/10 rounded-lg border border-border" data-testid="status-current">
              <div className="text-2xl font-bold text-primary">
                {userKeyStatus?.status || "Ready"}
              </div>
              <div className="text-sm text-primary">Current Status</div>
            </div>
            <div className="text-center p-4 bg-green-600/10 rounded-lg border border-border" data-testid="status-days-remaining">
              <div className="text-2xl font-bold text-green-600">
                {userKeyStatus?.daysRemaining !== undefined ? userKeyStatus.daysRemaining : "--"}
              </div>
              <div className="text-sm text-green-600">Days Remaining</div>
            </div>
          </div>
          
          {userKeyStatus?.activeKey && (
            <div className="mt-4 p-4 bg-green-600/10 border border-green-600/20 rounded-lg">
              <h4 className="text-sm font-medium text-green-600 mb-2">Active Key Details</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                <div className="text-muted-foreground">
                  <span>Key:</span> <span className="font-mono text-foreground">{userKeyStatus.activeKey.key}</span>
                </div>
                <div className="text-muted-foreground">
                  <span>Expires:</span> <span className="text-foreground">{new Date(userKeyStatus.activeKey.expiresAt).toLocaleDateString()}</span>
                </div>
                <div className="text-muted-foreground">
                  <span>Uses:</span> <span className="text-foreground">{userKeyStatus.activeKey.currentUses}/{userKeyStatus.activeKey.maxUses}</span>
                </div>
                {userKeyStatus.activeKey.discordUsername && (
                  <div className="text-muted-foreground">
                    <span>Discord:</span> <span className="text-foreground">{userKeyStatus.activeKey.discordUsername}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
