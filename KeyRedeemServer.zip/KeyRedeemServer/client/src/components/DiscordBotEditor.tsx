import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Code2, Play, Save, Trash2, Plus, Clock, CheckCircle, XCircle, Eye } from "lucide-react";
import type { DiscordBotCode, InsertDiscordBotCode, UpdateDiscordBotCode } from "@shared/schema";
import { BotConsole } from "./BotConsole";

export function DiscordBotEditor() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedBot, setSelectedBot] = useState<DiscordBotCode | null>(null);
  const [createData, setCreateData] = useState<InsertDiscordBotCode>({
    fileName: "",
    code: "",
    language: "javascript",
    description: "",
    isActive: true
  });
  const [editData, setEditData] = useState<UpdateDiscordBotCode>({});
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all Discord bot code
  const { data: botCodes = [], isLoading } = useQuery<DiscordBotCode[]>({
    queryKey: ["/api/admin/discord-bot-code"],
  });

  // Fetch deployment history
  const { data: deploymentHistory = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/deployment-history"],
  });

  // Create bot code mutation
  const createMutation = useMutation({
    mutationFn: async (data: InsertDiscordBotCode) => {
      const response = await apiRequest("POST", "/api/admin/discord-bot-code", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Discord bot code created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/discord-bot-code"] });
      setIsCreateModalOpen(false);
      setCreateData({
        fileName: "",
        code: "",
        language: "javascript",
        description: "",
        isActive: true
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create Discord bot code",
        variant: "destructive",
      });
    }
  });

  // Update bot code mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: UpdateDiscordBotCode }) => {
      const response = await apiRequest("PUT", `/api/admin/discord-bot-code/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Discord bot code updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/discord-bot-code"] });
      setIsEditModalOpen(false);
      setSelectedBot(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update Discord bot code",
        variant: "destructive",
      });
    }
  });

  // Delete bot code mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/admin/discord-bot-code/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Discord bot code deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/discord-bot-code"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete Discord bot code",
        variant: "destructive",
      });
    }
  });

  // Deploy bot code mutation
  const deployMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("POST", `/api/admin/discord-bot-code/${id}/deploy`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Deployment Success",
        description: "Discord bot code deployed successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/discord-bot-code"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/deployment-history"] });
    },
    onError: (error: any) => {
      toast({
        title: "Deployment Failed",
        description: error.message || "Failed to deploy Discord bot code",
        variant: "destructive",
      });
    }
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createData.fileName.trim() || !createData.code.trim()) {
      toast({
        title: "Validation Error",
        description: "File name and code are required",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate(createData);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBot) return;
    updateMutation.mutate({ id: selectedBot.id, data: editData });
  };

  const handleEdit = (bot: DiscordBotCode) => {
    setSelectedBot(bot);
    setEditData({
      fileName: bot.fileName,
      code: bot.code,
      description: bot.description || undefined,
      isActive: bot.isActive
    });
    setIsEditModalOpen(true);
  };

  const handleView = (bot: DiscordBotCode) => {
    setSelectedBot(bot);
    setIsViewModalOpen(true);
  };

  const handleDeploy = (id: string) => {
    deployMutation.mutate(id);
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this Discord bot code?")) {
      deleteMutation.mutate(id);
    }
  };

  const getStatusBadge = (bot: DiscordBotCode) => {
    if (bot.isActive && bot.lastDeployed) {
      return <Badge className="bg-green-600">Active</Badge>;
    } else if (bot.isActive) {
      return <Badge className="bg-yellow-600">Ready</Badge>;
    } else {
      return <Badge variant="secondary">Inactive</Badge>;
    }
  };

  const getRecentDeployment = (botId: string) => {
    return deploymentHistory
      .filter((deployment: any) => deployment.fileId === botId)
      .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Code2 className="h-5 w-5" />
              Discord Bot Code Manager
            </CardTitle>
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  New Bot Code
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Create New Discord Bot Code</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateSubmit} className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="fileName">File Name</Label>
                      <Input
                        id="fileName"
                        value={createData.fileName}
                        onChange={(e) => setCreateData({ ...createData, fileName: e.target.value })}
                        placeholder="e.g., bot.js or bot.py"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="language">Programming Language</Label>
                      <Select 
                        value={createData.language} 
                        onValueChange={(value: "javascript" | "python") => 
                          setCreateData({ ...createData, language: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="javascript">JavaScript/TypeScript</SelectItem>
                          <SelectItem value="python">Python</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Input
                        id="description"
                        value={createData.description || ""}
                        onChange={(e) => setCreateData({ ...createData, description: e.target.value })}
                        placeholder="Brief description of this bot code"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="code">Bot Code</Label>
                    <Textarea
                      id="code"
                      value={createData.code}
                      onChange={(e) => setCreateData({ ...createData, code: e.target.value })}
                      placeholder={`Enter your Discord bot ${createData.language === 'python' ? 'Python' : 'JavaScript/TypeScript'} code here...`}
                      className="min-h-[400px] font-mono text-sm"
                      required
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="isActive"
                      checked={createData.isActive}
                      onChange={(e) => setCreateData({ ...createData, isActive: e.target.checked })}
                      className="rounded"
                    />
                    <Label htmlFor="isActive">Active</Label>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending}>
                      {createMutation.isPending ? "Creating..." : "Create"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading bot codes...</div>
          ) : botCodes.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No Discord bot code files found. Create your first one!
            </div>
          ) : (
            <div className="grid gap-4">
              {botCodes.map((bot) => {
                const recentDeployment = getRecentDeployment(bot.id);
                return (
                  <Card key={bot.id} className="border-border/40">
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <h3 className="font-semibold text-lg">{bot.fileName}</h3>
                            {getStatusBadge(bot)}
                            <Badge variant="outline">v{bot.version}</Badge>
                            <Badge 
                              variant="secondary" 
                              className={bot.language === 'python' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'}
                            >
                              {bot.language === 'python' ? 'Python' : 'JavaScript'}
                            </Badge>
                          </div>
                          {bot.description && (
                            <p className="text-muted-foreground text-sm">{bot.description}</p>
                          )}
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              Updated: {new Date(bot.updatedAt).toLocaleDateString()}
                            </span>
                            {bot.lastDeployed && (
                              <span className="flex items-center gap-1">
                                <CheckCircle className="h-3 w-3 text-green-500" />
                                Deployed: {new Date(bot.lastDeployed).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                          {recentDeployment && (
                            <div className="flex items-center gap-2 text-sm">
                              <span>Last deployment:</span>
                              {recentDeployment.status === 'success' ? (
                                <Badge className="bg-green-600 text-xs">Success</Badge>
                              ) : (
                                <Badge variant="destructive" className="text-xs">Failed</Badge>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleView(bot)}
                            className="flex items-center gap-1"
                          >
                            <Eye className="h-3 w-3" />
                            View
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(bot)}
                            className="flex items-center gap-1"
                          >
                            <Save className="h-3 w-3" />
                            Edit
                          </Button>
                          <BotConsole 
                            botId={bot.id} 
                            botName={bot.fileName} 
                            language={bot.language} 
                          />
                          <Button
                            size="sm"
                            onClick={() => handleDeploy(bot.id)}
                            disabled={deployMutation.isPending}
                            className="flex items-center gap-1"
                          >
                            <Play className="h-3 w-3" />
                            {deployMutation.isPending ? "Deploying..." : "Deploy"}
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDelete(bot.id)}
                            disabled={deleteMutation.isPending}
                            className="flex items-center gap-1"
                          >
                            <Trash2 className="h-3 w-3" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Discord Bot Code</DialogTitle>
          </DialogHeader>
          {selectedBot && (
            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="editFileName">File Name</Label>
                  <Input
                    id="editFileName"
                    value={editData.fileName || ""}
                    onChange={(e) => setEditData({ ...editData, fileName: e.target.value })}
                    placeholder="e.g., bot.js or bot.py"
                  />
                </div>
                <div>
                  <Label htmlFor="editLanguage">Programming Language</Label>
                  <Select 
                    value={editData.language || selectedBot.language} 
                    onValueChange={(value: "javascript" | "python") => 
                      setEditData({ ...editData, language: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="javascript">JavaScript/TypeScript</SelectItem>
                      <SelectItem value="python">Python</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="editDescription">Description</Label>
                  <Input
                    id="editDescription"
                    value={editData.description || ""}
                    onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                    placeholder="Brief description of this bot code"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="editCode">Bot Code</Label>
                <Textarea
                  id="editCode"
                  value={editData.code || ""}
                  onChange={(e) => setEditData({ ...editData, code: e.target.value })}
                  placeholder={`Enter your Discord bot ${(editData.language || selectedBot.language) === 'python' ? 'Python' : 'JavaScript/TypeScript'} code here...`}
                  className="min-h-[400px] font-mono text-sm"
                />
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="editIsActive"
                  checked={editData.isActive ?? false}
                  onChange={(e) => setEditData({ ...editData, isActive: e.target.checked })}
                  className="rounded"
                />
                <Label htmlFor="editIsActive">Active</Label>
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsEditModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Updating..." : "Update"}
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* View Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>View Discord Bot Code</DialogTitle>
          </DialogHeader>
          {selectedBot && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>File Name</Label>
                  <div className="p-2 bg-muted rounded text-sm">{selectedBot.fileName}</div>
                </div>
                <div>
                  <Label>Version</Label>
                  <div className="p-2 bg-muted rounded text-sm">v{selectedBot.version}</div>
                </div>
                {selectedBot.description && (
                  <div className="col-span-2">
                    <Label>Description</Label>
                    <div className="p-2 bg-muted rounded text-sm">{selectedBot.description}</div>
                  </div>
                )}
              </div>
              <div>
                <Label>Bot Code (Read Only)</Label>
                <Textarea
                  value={selectedBot.code}
                  readOnly
                  className="min-h-[400px] font-mono text-sm bg-muted"
                />
              </div>
              <div className="flex justify-end">
                <Button onClick={() => setIsViewModalOpen(false)}>
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}