import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Mail, Plus, Trash2, Copy, Clock, CheckCircle, XCircle } from "lucide-react";
import type { AdminInvitation, InsertAdminInvitation } from "@shared/schema";

export function AdminInvitationManager() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [createData, setCreateData] = useState<InsertAdminInvitation>({
    email: "",
    role: "admin"
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all admin invitations
  const { data: invitations = [], isLoading } = useQuery<AdminInvitation[]>({
    queryKey: ["/api/admin/invitations"],
  });

  // Create invitation mutation
  const createMutation = useMutation({
    mutationFn: async (data: InsertAdminInvitation) => {
      const response = await apiRequest("POST", "/api/admin/invitations", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Invitation Created",
        description: `Admin invitation sent to ${data.invitation.email}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/invitations"] });
      setIsCreateModalOpen(false);
      setCreateData({ email: "", role: "admin" });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create admin invitation",
        variant: "destructive",
      });
    }
  });

  // Delete invitation mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/admin/invitations/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Admin invitation deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/invitations"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete admin invitation",
        variant: "destructive",
      });
    }
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createData.email.trim()) {
      toast({
        title: "Validation Error",
        description: "Email is required",
        variant: "destructive",
      });
      return;
    }
    
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(createData.email)) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }
    
    createMutation.mutate(createData);
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this invitation?")) {
      deleteMutation.mutate(id);
    }
  };

  const copyInviteLink = (inviteCode: string) => {
    const inviteUrl = `${window.location.origin}/admin-signup?code=${inviteCode}`;
    navigator.clipboard.writeText(inviteUrl);
    toast({
      title: "Copied!",
      description: "Invitation link copied to clipboard",
    });
  };

  const copyInviteCode = (inviteCode: string) => {
    navigator.clipboard.writeText(inviteCode);
    toast({
      title: "Copied!",
      description: "Invitation code copied to clipboard",
    });
  };

  const getStatusBadge = (invitation: AdminInvitation) => {
    if (invitation.used) {
      return (
        <Badge className="bg-green-600 flex items-center gap-1">
          <CheckCircle className="h-3 w-3" />
          Used
        </Badge>
      );
    } else if (new Date() > new Date(invitation.expiresAt)) {
      return (
        <Badge variant="destructive" className="flex items-center gap-1">
          <XCircle className="h-3 w-3" />
          Expired
        </Badge>
      );
    } else {
      return (
        <Badge className="bg-yellow-600 flex items-center gap-1">
          <Clock className="h-3 w-3" />
          Pending
        </Badge>
      );
    }
  };

  const getRoleBadge = (role: string) => {
    const roleColors: Record<string, string> = {
      admin: "bg-blue-600",
      super_admin: "bg-purple-600",
      moderator: "bg-orange-600"
    };
    
    return (
      <Badge className={roleColors[role] || "bg-gray-600"}>
        {role.replace('_', ' ').toUpperCase()}
      </Badge>
    );
  };

  const activeInvitations = invitations.filter(inv => !inv.used && new Date() <= new Date(inv.expiresAt));
  const usedInvitations = invitations.filter(inv => inv.used);
  const expiredInvitations = invitations.filter(inv => !inv.used && new Date() > new Date(inv.expiresAt));

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Admin Invitation Manager
            </CardTitle>
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Send Invitation
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Admin Invitation</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={createData.email}
                      onChange={(e) => setCreateData({ ...createData, email: e.target.value })}
                      placeholder="admin@example.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="role">Role</Label>
                    <Select
                      value={createData.role}
                      onValueChange={(value) => setCreateData({ ...createData, role: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="super_admin">Super Admin</SelectItem>
                        <SelectItem value="moderator">Moderator</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    The invitation will expire in 7 days and can only be used once.
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending}>
                      {createMutation.isPending ? "Creating..." : "Send Invitation"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Summary Stats */}
            <div className="grid grid-cols-3 gap-4">
              <Card className="border-border/40">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-500">{activeInvitations.length}</div>
                    <div className="text-sm text-muted-foreground">Active Invitations</div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/40">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-500">{usedInvitations.length}</div>
                    <div className="text-sm text-muted-foreground">Used Invitations</div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/40">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-500">{expiredInvitations.length}</div>
                    <div className="text-sm text-muted-foreground">Expired Invitations</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Invitations List */}
            {isLoading ? (
              <div className="text-center py-8">Loading invitations...</div>
            ) : invitations.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No admin invitations found. Create your first one!
              </div>
            ) : (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">All Invitations</h3>
                {invitations.map((invitation) => (
                  <Card key={invitation.id} className="border-border/40">
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <span className="font-medium">{invitation.email}</span>
                            {getStatusBadge(invitation)}
                            {getRoleBadge(invitation.role)}
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                            <span>Created: {new Date(invitation.createdAt).toLocaleDateString()}</span>
                            <span>Expires: {new Date(invitation.expiresAt).toLocaleDateString()}</span>
                            {invitation.used && invitation.usedAt && (
                              <span>Used: {new Date(invitation.usedAt).toLocaleDateString()}</span>
                            )}
                          </div>
                          {!invitation.used && new Date() <= new Date(invitation.expiresAt) && (
                            <div className="flex items-center gap-2">
                              <code className="text-xs bg-muted px-2 py-1 rounded">
                                {invitation.inviteCode}
                              </code>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => copyInviteCode(invitation.inviteCode)}
                                className="text-xs"
                              >
                                <Copy className="h-3 w-3 mr-1" />
                                Copy Code
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => copyInviteLink(invitation.inviteCode)}
                                className="text-xs"
                              >
                                <Copy className="h-3 w-3 mr-1" />
                                Copy Link
                              </Button>
                            </div>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          {!invitation.used && (
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleDelete(invitation.id)}
                              disabled={deleteMutation.isPending}
                              className="flex items-center gap-1"
                            >
                              <Trash2 className="h-3 w-3" />
                              Delete
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}