import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronRight, ExternalLink, Info } from "lucide-react";

export function DiscordSetupGuide() {
  const [isOpen, setIsOpen] = useState(false);

  const steps = [
    {
      title: "Create Discord Application",
      description: "Set up your Discord bot application",
      steps: [
        "Go to https://discord.com/developers/applications",
        "Click 'New Application' and give it a name",
        "Navigate to the 'Bot' section and click 'Add Bot'",
        "Copy the bot token for your environment variables"
      ]
    },
    {
      title: "Configure Bot Permissions", 
      description: "Set the required permissions for your bot",
      steps: [
        "In the Bot section, scroll down to 'Privileged Gateway Intents'",
        "Enable 'MESSAGE CONTENT INTENT' if needed",
        "Go to OAuth2 > URL Generator",
        "Select 'bot' and 'applications.commands' scopes",
        "Select these permissions: 'Send Messages', 'Use Slash Commands', 'Read Message History'"
      ]
    },
    {
      title: "Add Bot to Server",
      description: "Invite your bot to your Discord server",
      steps: [
        "Copy the generated OAuth2 URL from the previous step",
        "Open the URL in your browser",
        "Select your Discord server and authorize the bot",
        "The bot should now appear in your server member list"
      ]
    },
    {
      title: "Get Server Information",
      description: "Collect required server details",
      steps: [
        "Enable Developer Mode in Discord (User Settings > Advanced > Developer Mode)",
        "Right-click your server name and select 'Copy ID' for DISCORD_GUILD_ID",
        "Optionally, create a webhook in Server Settings > Integrations > Webhooks for notifications"
      ]
    },
    {
      title: "Update Environment Variables",
      description: "Configure your application with Discord credentials",
      steps: [
        "Add DISCORD_BOT_TOKEN=your_bot_token",
        "Add DISCORD_GUILD_ID=your_server_id", 
        "Add DISCORD_WEBHOOK_URL=your_webhook_url (optional)",
        "Restart your application to apply changes"
      ]
    }
  ];

  return (
    <Card className="p-6">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" className="w-full justify-between p-0 h-auto">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <i className="fab fa-discord text-indigo-600 text-xl"></i>
              </div>
              <div className="text-left">
                <h3 className="text-lg font-semibold text-gray-900">Discord Bot Setup Guide</h3>
                <p className="text-sm text-gray-600">Configure Discord integration for key redemption</p>
              </div>
            </div>
            {isOpen ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
          </Button>
        </CollapsibleTrigger>
        
        <CollapsibleContent className="mt-6">
          <Alert className="mb-6">
            <Info className="h-4 w-4" />
            <AlertDescription>
              Discord integration is optional but provides seamless key redemption through Discord commands.
              Users can redeem keys using <code>/redeem</code> and check status with <code>/status</code>.
            </AlertDescription>
          </Alert>

          <div className="space-y-6">
            {steps.map((step, index) => (
              <div key={index} className="border-l-4 border-indigo-200 pl-4">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="h-6 w-6 bg-indigo-600 text-white rounded-full flex items-center justify-center text-sm font-semibold">
                    {index + 1}
                  </div>
                  <h4 className="font-semibold text-gray-900">{step.title}</h4>
                </div>
                <p className="text-sm text-gray-600 mb-3">{step.description}</p>
                <ul className="space-y-1">
                  {step.steps.map((stepItem, stepIndex) => (
                    <li key={stepIndex} className="text-sm text-gray-700 flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>{stepItem}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <h4 className="font-semibold text-gray-900 mb-3">Useful Links</h4>
            <div className="space-y-2">
              <a 
                href="https://discord.com/developers/applications" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center text-indigo-600 hover:text-indigo-800 text-sm"
              >
                <ExternalLink className="h-4 w-4 mr-1" />
                Discord Developer Portal
              </a>
              <a 
                href="https://discord.js.org/#/docs/discord.js/main/general/welcome" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center text-indigo-600 hover:text-indigo-800 text-sm"
              >
                <ExternalLink className="h-4 w-4 mr-1" />
                Discord.js Documentation
              </a>
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}