import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: 'active' | 'unused' | 'expired' | 'redeemed';
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const variants = {
    active: "bg-green-100 text-green-800",
    unused: "bg-amber-100 text-amber-800", 
    expired: "bg-red-100 text-red-800",
    redeemed: "bg-blue-100 text-blue-800"
  };

  const icons = {
    active: "fas fa-check-circle",
    unused: "fas fa-clock",
    expired: "fas fa-times-circle", 
    redeemed: "fas fa-check-circle"
  };

  return (
    <span className={cn(
      "inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full",
      variants[status],
      className
    )}>
      <i className={`${icons[status]} mr-1`}></i>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}
