import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { DiscordLog } from "@shared/schema";

export function DiscordLogs() {
  const { data: logs = [], isLoading } = useQuery<DiscordLog[]>({
    queryKey: ["/api/admin/discord-logs"],
  });

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'KEY_REDEEM_ATTEMPT':
        return 'fas fa-key text-blue-500';
      case 'KEY_REDEEM_RESULT':
        return 'fas fa-check-circle text-green-500';
      case 'STATUS_CHECK':
        return 'fas fa-info-circle text-gray-500';
      default:
        return 'fas fa-circle text-gray-400';
    }
  };

  const getActionColor = (action: string, success: boolean) => {
    if (action === 'KEY_REDEEM_RESULT') {
      return success ? 'text-green-600' : 'text-red-600';
    }
    return 'text-gray-600';
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <i className="fab fa-discord text-indigo-500 mr-2"></i>
            Discord Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            Loading Discord activity...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <i className="fab fa-discord text-indigo-500 mr-2"></i>
            Discord Activity
          </div>
          <span className="text-sm font-normal text-gray-500">
            {logs.length} total events
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {logs.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <i className="fab fa-discord text-gray-300 text-4xl mb-3"></i>
            <p>No Discord activity yet</p>
            <p className="text-sm">Activity will appear here when users interact with the bot</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {logs.map((log) => (
              <div key={log.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className="flex-shrink-0 mt-1">
                  <i className={getActionIcon(log.action)}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900">
                      {log.discordUsername}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(log.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <p className={`text-sm ${getActionColor(log.action, log.success)}`}>
                    {log.details}
                  </p>
                  {log.keyValue && (
                    <p className="text-xs text-gray-500 font-mono">
                      Key: {log.keyValue}
                    </p>
                  )}
                  <div className="flex items-center mt-1 space-x-2">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                      log.success 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {log.success ? 'Success' : 'Failed'}
                    </span>
                    <span className="text-xs text-gray-400">
                      ID: {log.discordUserId}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}