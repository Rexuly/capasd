import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Terminal, Play, Square, RotateCcw, Trash2, Wifi, WifiOff, Activity } from 'lucide-react';
import { useBotConsole, type BotInstance, type BotLog } from '@/hooks/useBotConsole';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface BotConsoleProps {
  botId: string;
  botName: string;
  language: string;
}

export function BotConsole({ botId, botName, language }: BotConsoleProps) {
  const { bots, isConnected, getBotStatus, getBotLogs } = useBotConsole();
  const [isOpen, setIsOpen] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const bot = getBotStatus(botId);
  const logs = getBotLogs(botId);

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const stopMutation = useMutation({
    mutationFn: async () => await apiRequest(`/api/admin/bot-stop/${botId}`, 'POST'),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Bot stopped successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const restartMutation = useMutation({
    mutationFn: async () => await apiRequest(`/api/admin/bot-restart/${botId}`, 'POST'),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Bot restarted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const clearLogsMutation = useMutation({
    mutationFn: async () => await apiRequest(`/api/admin/bot-logs/${botId}`, 'DELETE'),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Bot logs cleared successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'running':
        return <Badge className="bg-green-600">Running</Badge>;
      case 'starting':
        return <Badge className="bg-yellow-600">Starting</Badge>;
      case 'stopped':
        return <Badge variant="secondary">Stopped</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      case 'crashed':
        return <Badge variant="destructive">Crashed</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getLogLevelColor = (level: string) => {
    switch (level) {
      case 'error':
        return 'text-red-400';
      case 'warn':
        return 'text-yellow-400';
      case 'info':
        return 'text-blue-400';
      case 'debug':
        return 'text-gray-400';
      default:
        return 'text-gray-300';
    }
  };

  const formatTimestamp = (timestamp: Date) => {
    return timestamp.toLocaleTimeString('en-US', { 
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center gap-1">
          <Terminal className="h-3 w-3" />
          Console
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5" />
            Bot Console - {botName}
            <Badge variant="outline" className={language === 'python' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'}>
              {language === 'python' ? 'Python' : 'JavaScript'}
            </Badge>
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex flex-col space-y-4 h-[70vh]">
          {/* Status and Controls */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Status:</span>
                    {bot ? getStatusBadge(bot.status) : <Badge variant="outline">Not Found</Badge>}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {isConnected ? (
                      <><Wifi className="h-4 w-4 text-green-500" /><span className="text-sm text-green-500">Connected</span></>
                    ) : (
                      <><WifiOff className="h-4 w-4 text-red-500" /><span className="text-sm text-red-500">Disconnected</span></>
                    )}
                  </div>

                  {bot?.pid && (
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4" />
                      <span className="text-sm">PID: {bot.pid}</span>
                    </div>
                  )}

                  {bot?.startTime && (
                    <div className="text-sm text-muted-foreground">
                      Started: {bot.startTime.toLocaleString()}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => restartMutation.mutate()}
                    disabled={restartMutation.isPending}
                    className="flex items-center gap-1"
                  >
                    <RotateCcw className="h-3 w-3" />
                    Restart
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => stopMutation.mutate()}
                    disabled={stopMutation.isPending || bot?.status === 'stopped'}
                    className="flex items-center gap-1"
                  >
                    <Square className="h-3 w-3" />
                    Stop
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => clearLogsMutation.mutate()}
                    disabled={clearLogsMutation.isPending}
                    className="flex items-center gap-1"
                  >
                    <Trash2 className="h-3 w-3" />
                    Clear Logs
                  </Button>
                </div>
              </div>

              {bot?.lastError && (
                <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
                  <div className="text-sm font-medium text-red-800 dark:text-red-300">Last Error:</div>
                  <div className="text-sm text-red-700 dark:text-red-400 mt-1 font-mono">{bot.lastError}</div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Console Output */}
          <Card className="flex-1">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">Console Output</CardTitle>
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={autoScroll}
                      onChange={(e) => setAutoScroll(e.target.checked)}
                      className="rounded"
                    />
                    Auto-scroll
                  </label>
                  <Badge variant="outline" className="text-xs">
                    {logs.length} logs
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <ScrollArea className="h-[400px] w-full border rounded-md">
                <div ref={scrollRef} className="p-4 font-mono text-sm space-y-1">
                  {logs.length === 0 ? (
                    <div className="text-muted-foreground text-center py-8">
                      No logs available. Deploy the bot to see console output.
                    </div>
                  ) : (
                    logs.map((log) => (
                      <div key={log.id} className="flex gap-2 text-xs">
                        <span className="text-muted-foreground shrink-0">
                          {formatTimestamp(log.timestamp)}
                        </span>
                        <span className={`shrink-0 uppercase ${getLogLevelColor(log.level)}`}>
                          [{log.level}]
                        </span>
                        <span className={`shrink-0 text-muted-foreground`}>
                          [{log.source}]
                        </span>
                        <span className="text-foreground break-all">
                          {log.message}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}