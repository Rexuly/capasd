import { Switch, Route } from "wouter";
import { queryClient, getAuthToken, removeAuthToken, getAdminInfo } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState, useEffect } from "react";
import UserView from "@/pages/user-view";
import AdminView from "@/pages/admin-view";
import Login from "@/pages/login";
import AdminSignup from "@/pages/admin-signup";
import NotFound from "@/pages/not-found";

function Router() {
  const [currentView, setCurrentView] = useState<'user' | 'admin'>('user');
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [adminInfo, setAdminInfo] = useState<any>(null);

  useEffect(() => {
    const token = getAuthToken();
    const admin = getAdminInfo();
    if (token && admin) {
      setIsAuthenticated(true);
      setAdminInfo(admin);
    }
  }, []);

  const handleLogin = (token: string, admin: any) => {
    setIsAuthenticated(true);
    setAdminInfo(admin);
  };

  const handleLogout = () => {
    removeAuthToken();
    setIsAuthenticated(false);
    setAdminInfo(null);
    setCurrentView('user');
  };

  // Show login page for admin view if not authenticated
  if (currentView === 'admin' && !isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background font-sans dark">
      {/* Navigation Header */}
      <nav className="bg-card shadow-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <i className="fas fa-key text-primary text-2xl"></i>
              </div>
              <div className="ml-3">
                <h1 className="text-xl font-semibold text-foreground">Captha Lua Key Redeem</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setCurrentView('user')}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  currentView === 'user'
                    ? 'text-primary bg-primary/10 hover:bg-primary/20'
                    : 'text-foreground bg-secondary/20 hover:bg-secondary/30'
                }`}
                data-testid="button-user-view"
              >
                <i className="fas fa-user mr-2"></i>User View
              </button>
              <button
                onClick={() => setCurrentView('admin')}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  currentView === 'admin'
                    ? 'text-primary bg-primary/10 hover:bg-primary/20'
                    : 'text-foreground bg-secondary/20 hover:bg-secondary/30'
                }`}
                data-testid="button-admin-panel"
              >
                <i className="fab fa-discord mr-2"></i>Admin Panel
              </button>
              {isAuthenticated && currentView === 'admin' && (
                <>
                  <div className="flex items-center text-sm text-foreground" data-testid="text-admin-username">
                    <i className="fas fa-user-shield mr-1"></i>
                    {adminInfo?.username}
                  </div>
                  <button
                    onClick={handleLogout}
                    className="px-3 py-1 text-sm text-red-500 hover:text-red-400 hover:bg-red-500/10 rounded-md transition-colors"
                    data-testid="button-logout"
                  >
                    <i className="fas fa-sign-out-alt mr-1"></i>Logout
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Switch>
          <Route path="/">
            {currentView === 'user' ? <UserView /> : <AdminView />}
          </Route>
          <Route path="/admin-signup" component={AdminSignup} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
