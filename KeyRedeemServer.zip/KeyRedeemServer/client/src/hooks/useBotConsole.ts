import { useState, useEffect, useRef } from 'react';

export interface BotLog {
  id: string;
  timestamp: Date;
  level: 'info' | 'warn' | 'error' | 'debug';
  message: string;
  source: 'stdout' | 'stderr' | 'system';
}

export interface BotInstance {
  id: string;
  fileName: string;
  language: string;
  status: 'starting' | 'running' | 'stopped' | 'error' | 'crashed';
  pid?: number;
  startTime?: Date;
  lastError?: string;
  logs: BotLog[];
  port?: number;
}

export function useBotConsole() {
  const [bots, setBots] = useState<Map<string, BotInstance>>(new Map());
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const connectWebSocket = () => {
      wsRef.current = new WebSocket(wsUrl);
      
      wsRef.current.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);
      };
      
      wsRef.current.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          
          switch (message.type) {
            case 'initial':
              // Initial bot data
              const botMap = new Map<string, BotInstance>();
              message.data.forEach((bot: BotInstance) => {
                // Convert timestamp strings back to Date objects
                bot.logs = bot.logs.map(log => ({
                  ...log,
                  timestamp: new Date(log.timestamp)
                }));
                if (bot.startTime) {
                  bot.startTime = new Date(bot.startTime);
                }
                botMap.set(bot.id, bot);
              });
              setBots(botMap);
              break;
              
            case 'log':
              // New log entry
              const { botId, log } = message.data;
              setBots(prev => {
                const newBots = new Map(prev);
                const bot = newBots.get(botId);
                if (bot) {
                  const newLog = {
                    ...log,
                    timestamp: new Date(log.timestamp)
                  };
                  bot.logs.push(newLog);
                  // Keep only last 500 logs
                  if (bot.logs.length > 500) {
                    bot.logs = bot.logs.slice(-500);
                  }
                  newBots.set(botId, { ...bot });
                }
                return newBots;
              });
              break;
              
            case 'statusChange':
              // Bot status change
              const { botId: statusBotId, status } = message.data;
              setBots(prev => {
                const newBots = new Map(prev);
                const bot = newBots.get(statusBotId);
                if (bot) {
                  newBots.set(statusBotId, { ...bot, status });
                }
                return newBots;
              });
              break;
          }
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
      
      wsRef.current.onclose = () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
        // Attempt to reconnect after 3 seconds
        setTimeout(connectWebSocket, 3000);
      };
      
      wsRef.current.onerror = (error) => {
        console.error('WebSocket error:', error);
        setIsConnected(false);
      };
    };
    
    connectWebSocket();
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const getBotStatus = (botId: string): BotInstance | undefined => {
    return bots.get(botId);
  };

  const getBotLogs = (botId: string): BotLog[] => {
    const bot = bots.get(botId);
    return bot?.logs || [];
  };

  return {
    bots: Array.from(bots.values()),
    isConnected,
    getBotStatus,
    getBotLogs
  };
}