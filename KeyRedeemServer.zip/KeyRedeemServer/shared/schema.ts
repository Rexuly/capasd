import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const admins = pgTable("admins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("admin"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const keys = pgTable("keys", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(),
  isRedeemed: boolean("is_redeemed").default(false).notNull(),
  hardwareId: text("hardware_id"),
  discordUserId: text("discord_user_id"),
  discordUsername: text("discord_username"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  redeemedAt: timestamp("redeemed_at"),
  maxUses: integer("max_uses").default(1).notNull(),
  currentUses: integer("current_uses").default(0).notNull(),
  allowMultipleHardware: boolean("allow_multiple_hardware").default(false).notNull(),
  notes: text("notes"),
});

export const discordLogs = pgTable("discord_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  action: text("action").notNull(),
  discordUserId: text("discord_user_id").notNull(),
  discordUsername: text("discord_username").notNull(),
  keyValue: text("key_value"),
  details: text("details"),
  success: boolean("success").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const discordBotCode = pgTable("discord_bot_code", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: text("file_name").notNull(),
  code: text("code").notNull(),
  language: varchar("language", { length: 20 }).notNull().default("javascript"), // javascript, python
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
  version: integer("version").default(1).notNull(),
  lastDeployed: timestamp("last_deployed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const adminInvitations = pgTable("admin_invitations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("admin"),
  inviteCode: text("invite_code").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false).notNull(),
  usedAt: timestamp("used_at"),
  createdBy: varchar("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const deploymentHistory = pgTable("deployment_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileId: varchar("file_id").notNull(),
  version: integer("version").notNull(),
  deployedBy: varchar("deployed_by").notNull(),
  status: text("status").notNull().default("pending"), // pending, success, failed
  logs: text("logs"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAdminSchema = createInsertSchema(admins).pick({
  username: true,
  passwordHash: true,
  role: true,
});

export const insertKeySchema = createInsertSchema(keys).pick({
  key: true,
  expiresAt: true,
  maxUses: true,
  allowMultipleHardware: true,
  notes: true,
});

export const redeemKeySchema = z.object({
  key: z.string().min(1, "Key is required"),
  hardwareId: z.string().min(1, "Hardware ID is required"),
  discordUserId: z.string().optional(),
  discordUsername: z.string().optional(),
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export const insertDiscordLogSchema = createInsertSchema(discordLogs).pick({
  action: true,
  discordUserId: true,
  discordUsername: true,
  keyValue: true,
  details: true,
  success: true,
});

export const insertDiscordBotCodeSchema = createInsertSchema(discordBotCode).pick({
  fileName: true,
  code: true,
  language: true,
  description: true,
  isActive: true,
});

export const insertAdminInvitationSchema = createInsertSchema(adminInvitations).pick({
  email: true,
  role: true,
});

export const updateDiscordBotCodeSchema = z.object({
  fileName: z.string().optional(),
  code: z.string().optional(),
  language: z.enum(["javascript", "python"]).optional(),
  description: z.string().optional(),
  isActive: z.boolean().optional(),
});

export const adminInviteAcceptSchema = z.object({
  inviteCode: z.string().min(1, "Invite code is required"),
  username: z.string().min(1, "Username is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type Admin = typeof admins.$inferSelect;
export type InsertKey = z.infer<typeof insertKeySchema>;
export type Key = typeof keys.$inferSelect;
export type RedeemKey = z.infer<typeof redeemKeySchema>;
export type LoginData = z.infer<typeof loginSchema>;
export type InsertDiscordLog = z.infer<typeof insertDiscordLogSchema>;
export type DiscordLog = typeof discordLogs.$inferSelect;
export type InsertDiscordBotCode = z.infer<typeof insertDiscordBotCodeSchema>;
export type DiscordBotCode = typeof discordBotCode.$inferSelect;
export type UpdateDiscordBotCode = z.infer<typeof updateDiscordBotCodeSchema>;
export type InsertAdminInvitation = z.infer<typeof insertAdminInvitationSchema>;
export type AdminInvitation = typeof adminInvitations.$inferSelect;
export type AdminInviteAccept = z.infer<typeof adminInviteAcceptSchema>;
export type DeploymentHistory = typeof deploymentHistory.$inferSelect;
